"""Pure choices: given facts (a probe document, a codec name, a path, a flag value), return the
arguments or the value that follows from them.

Nothing here starts a subprocess or touches a media file, which is what makes the copy-vs-re-encode
and encoder-selection rules testable on their own.
"""
from __future__ import annotations

import math
import os
import re
from fractions import Fraction
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any, Dict, List, Optional, Sequence, Tuple
from _common.color import (as_limited, bt709_label_filter, bt709_line_filter, bt709_matrix_args, bt709_matrix_filter, bt709_tag_args, drawn_stream_format,
                           hdr_line_matrix, hdr_rgb_matrix_args, hdr_rgb_matrix_filter, is_neutral_color, limited_range_filter, rgb_island, rgb_to_bt709_filter, _sdr_bt709)
from _common.alpha import rgb_to_bt709_line
from _common.emit import die, input_length, note, record_fallback, refuse, warn
from _common.runner import absent_word, file_arg, read_json
from _common.probe import AUDIO_MEDIA_EXT, display_size
from _common.runner import CODECS, STATE, ffmpeg_encoders, ffmpeg_list_error, ffmpeg_version, hw_platform_reason


def boxblur_chroma_radius(want: int) -> str:
    """boxblur's chroma radius as an expression boxblur evaluates on the chroma planes' own size
    (cw x ch, so a 4:1:1 or 4:1:0 frame's quarter-width planes are what is measured, not an assumed
    4:2:0): `want`, or the largest radius that plane holds, floor((min(cw, ch) - 1) / 2), or 0 on a
    plane too small for 1. On 4:2:0 that is redact.py's earlier (min(w, h) // 2 - 1) // 2. boxblur
    refuses a radius above half the plane (6.1); 7.1 also refuses 1 on a 2 px plane, which this
    bound leaves out (#527)."""
    return f"max(0\\,min({int(want)}\\,floor((min(cw\\,ch)-1)/2)))"


def pad_filters(out_w: int, out_h: int, fill: str, color: str, blur: int, darken: float = 0.0,
                meta: Optional[Dict[str, Any]] = None, blank: bool = False) -> str:
    """The letterbox/pillarbox step shared by fit.py and export.py, as one -vf segment.

    fill="color": scale to fit, then pad with a solid colour (the historical behaviour).
    fill="blur": the bars are a blurred, scaled-to-cover copy of the same frame -- what every
    phone editor's "make it vertical" does with landscape footage (#139). Built as a small
    graph inside the -vf chain: split, one branch scaled to cover and cropped to the frame
    then boxblur'ed, the other scaled to fit, overlaid centred. Only `filter:boxblur` is
    needed beyond the usual scale/pad set, and that is already required by redact.py.
    `darken` > 0 also dims that background copy by that much brightness (eq), so the picture in
    front reads as the subject instead of competing with a bright blurred copy of itself --
    what `fit.py --fit blur` uses (1.14).
    `meta`: the probe of the picture being padded, when the output is that picture's re-encode: a
    --pad-color with chroma is then drawn in the BT.709 the line tags (drawn_chain()). Without it
    (a still made RGB, an export to GIF) the pad is what it always was.
    `blank` (fit.py's picture measurement, #519): the blurred copy is drawn black instead, so it
    does not change with the picture; the graph is otherwise the same."""
    if fill == "blur":
        # boxblur rejects a radius larger than half the smaller dimension ("radius 20, must be
        # <= 8" on a 16 px target); clamp instead of failing an otherwise valid request
        radius = max(1, min(int(blur), max(1, min(out_w, out_h) // 2 - 1)))
        # left unset, the chroma radius was the luma one, and a 4:2:0 68x120 frame's 34x60 chroma
        # planes failed at 20 ("must be <= 17", #527). On a larger frame it is still the luma one
        chroma = boxblur_chroma_radius(radius)
        return (f"split[__fitfg][__fitbg];"
                f"[__fitbg]scale={out_w}:{out_h}:force_original_aspect_ratio=increase,crop={out_w}:{out_h},"
                + ("drawbox=c=black:t=fill" if blank else
                   f"boxblur={radius}:2:{chroma}:2" + (f",eq=brightness=-{darken:g}" if darken else "")) + "[__fitbgb];"
                f"[__fitfg]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease[__fitfgs];"
                f"[__fitbgb][__fitfgs]overlay=(W-w)/2:(H-h)/2:format=auto")
    # a picture of another shape is mostly bars in this frame (a 9:16 clip in 16:9 fills 32%): the
    # file is what the frame asks for, and the caller may not have asked for that frame's shape
    if meta is not None and not blank and all(d := display_size(meta.get("video"))) and (part := min(out_w / d[0], out_h / d[1]) ** 2 * d[0] * d[1] / (out_w * out_h)) < 0.5:
        warn(f"the picture fills {part:.0%} of the {out_w}x{out_h} frame and the rest is bars: the source is {d[0]}x{d[1]}, another shape. --fit crop fills the frame; a frame of the source's shape keeps all of it (export.py: reels, shorts and tiktok are 9:16, youtube and facebook 16:9)", "picture_small_in_frame", fraction=round(part, 3), source=f"{d[0]}x{d[1]}", frame=f"{out_w}x{out_h}")
    pad = f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color="
    return (f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease,"
            + (pad + color if meta is None else drawn_chain(pad + color, meta, [color], pad + "black", tag="pad")))


def warn_mostly_cropped(video: Optional[Dict[str, Any]], out_w: int, out_h: int) -> None:
    """A crop to another shape that keeps less than half of the picture says so (#688), as a pad
    that leaves the picture small does (picture_small_in_frame): a 1920x1080 clip cropped to 9:16
    keeps the centre 32% of it. A warning only: a vertical crop of landscape footage is the usual
    way to make a Short, and the file is what was asked for."""
    if all(d := display_size(video)) and out_w and out_h and (part := min(out_w * d[1] / (out_h * d[0]), out_h * d[0] / (out_w * d[1]))) < 0.5:
        warn(f"the crop keeps {part:.0%} of the picture: the source is {d[0]}x{d[1]} and the frame {out_w}x{out_h}, another shape. --fit pad keeps all of it with bars, --fit blur over a blurred copy", "picture_mostly_cropped", fraction=round(part, 3), source=f"{d[0]}x{d[1]}", frame=f"{out_w}x{out_h}")


def add_pad_fill_args(parser: "argparse.ArgumentParser") -> None:
    parser.add_argument("--pad-fill", choices=["color", "blur"], default="color",
                        help="what fills the letterbox/pillarbox bars under --fit pad: a solid --pad-color (default) or a blurred, scaled-up copy of the frame")
    parser.add_argument("--pad-blur", type=int, default=20, help="blur radius in pixels for --pad-fill blur (default 20)")


def aspect_ratio(value: Any) -> Optional[Fraction]:
    """An aspect written W:H as an exact ratio, or None. fit.py --aspect and --export-timeline's
    sequence frame read an aspect through this one function, so the export refuses `16/9` and
    `2.39:1` where the render hands them to fit.py, which refuses them too (the timeline once
    took them and wrote a sequence for a project whose render then failed in fit.py). Each side
    is read with int(), as fit.py read it in 2.2.1, so a patch release refuses nothing fit.py
    took: `+16:9` and `1_6:9` still parse, and `0:9` is a zero ratio, which frame_size() treats
    as no aspect (2.2.1 kept the source frame). render.py's frame_from_preset() keeps 2.2.1's
    looser match: it only picks the export preset's size."""
    parts = str(value).split(":")
    if len(parts) != 2:
        return None
    try:
        w, h = int(parts[0]), int(parts[1])
        ratio = Fraction(w, h)
    except (ValueError, ZeroDivisionError):
        return None
    # a negative side (`-16:9`, `16:-9`) is no aspect anyone means: frame_size() made a negative
    # frame of it, which fit.py's pad refused inside ffmpeg (kind ffmpeg) and the timeline wrote.
    # Each side is looked at, not the ratio: `-16:-9` is a positive fraction
    return None if w < 0 or h < 0 else ratio


def _even(n: float) -> int:
    v = int(round(n))
    return v if v % 2 == 0 else v + 1


# A frame larger than the picture is enlarged with Lanczos in place of swscale's default bicubic:
# fewer soft edges where a 720p clip is delivered at 1080x1920. Nothing is added when the frame is
# the picture's size or smaller, so those commands are the ones they were.
def enlarge_args(meta: Optional[Dict[str, Any]], w: Optional[int], h: Optional[int]) -> List[str]:
    return ["-sws_flags", "lanczos"] if w and h and all(d := display_size((meta or {}).get("video"))) and (w > d[0] or h > d[1]) else []


def frame_size(ratio: Optional[Fraction], width: Optional[int], height: Optional[int],
               src_w: int, src_h: int) -> Tuple[int, int]:
    """The frame fit.py sizes for --aspect `ratio` (None: the source's own) and --width/--height,
    from a src_w x src_h picture -- and so the sequence frame render.py --export-timeline writes
    for the same project frame. Both sides given are used directly; one side takes the other from
    the aspect. With neither, the canvas takes the new aspect without exceeding the source's
    resolution in either dimension: a narrower/taller target than the source (e.g. 9:16 from a
    16:9 source) must be bounded by the source's HEIGHT, not its width -- bounding by width there
    multiplies the height by src_ratio/ratio (a 1920x1080 source asked for 9:16 used to come out
    1920x3414, a ~3.16x upscale in both fit=pad and fit=crop, entirely unrequested). Every side is
    rounded to even."""
    src_ratio = Fraction(src_w, src_h) if src_h else None
    if ratio is None:
        ratio = src_ratio
    if width and height:
        return _even(width), _even(height)
    if width:
        out_w = _even(width)
        return out_w, (_even(out_w / ratio) if ratio else width)
    if height:
        out_h = _even(height)
        return (_even(out_h * ratio) if ratio else height), out_h
    if ratio and src_ratio:
        if ratio <= src_ratio:
            out_h = _even(src_h)
            return _even(out_h * ratio), out_h
        out_w = _even(src_w)
        return out_w, _even(out_w / ratio)
    return _even(src_w), _even(src_h)


# x264 preset names mapped onto SVT-AV1's 0-13 speed scale (lower = slower / better)
SVT_PRESET = {"ultrafast": 12, "superfast": 11, "veryfast": 10, "faster": 9, "fast": 8, "medium": 6, "slow": 4, "slower": 3, "veryslow": 2, "placebo": 1}


# Source containers the tools' own encoders (x264/x265/SVT-AV1 and AAC) cannot be written into: WebM
# takes only VP8/VP9/AV1 and Vorbis/Opus. A default output name keeps the source's extension
# except for these, whose default is .mp4 (#415): the dry run planned `clip_loudnorm.webm` and the
# real run then failed in the muxer.
NO_DEFAULT_ENCODE_EXT = {".webm"}


def default_output(input_path: str, suffix: str, ext: Optional[str] = None) -> str:
    p = Path(input_path)
    if ext:
        new_ext = ext
    elif p.suffix.lower() in NO_DEFAULT_ENCODE_EXT:
        new_ext = "mp4"
    else:
        new_ext = p.suffix.lstrip(".") or "mp4"
    out = str(p.with_name(f"{p.stem}_{suffix}.{new_ext}"))
    # an input named -take.mp4 (given as ./-take.mp4 or after `--`) has a default output that
    # starts with a dash too, which run() refuses as option-shaped: name it as a file (#558)
    return file_arg(out)


class MissingFpsError(ValueError):
    """parse_time() saw an hh:mm:ss:ff SMPTE timecode but no fps was given to convert it -- distinct
    from a plain ValueError so a caller that falls back to treating unparseable text as a literal
    line (e.g. caption.py's free-text cue format) can still fail loudly on this one, instead of
    silently swallowing a mistyped/missing --fps as an auto-timed line of digits."""


def _on_windows() -> bool:
    """Whether a backslash in a path is a separator (Windows) or a character of the name."""
    return os.name == "nt"


def concat_list_line(path: str) -> str:
    """One `file '...'` line for the concat demuxer. The demuxer reads backslash as an escape
    inside the quoted form, so a Windows path (C:\\Users\\...\\part000.mp4) must be written
    with forward slashes -- ffmpeg opens either spelling on Windows -- and a single quote in the
    name is closed, escaped and reopened. Shared by cut.py (multi-segment) and sequence.py.

    A line break has no escape in this format: the demuxer reads each line as its own directive,
    so a name containing one would add `file` entries to the list and pull in files the caller
    never named. Such a path is refused."""
    if "\n" in str(path) or "\r" in str(path):
        refuse("input", "media_path_has_line_break",
               f"{str(path)!r} contains a line break, which ffmpeg's concat list cannot hold (each line is a "
               "directive of its own); rename the file", path=str(path))
    # only on Windows: on POSIX the quoted form takes a backslash literally, and it is part of the name (#408)
    escaped = (str(path).replace("\\", "/") if _on_windows() else str(path)).replace("'", "'\\''")
    return f"file '{escaped}'"


def fmt_secs(value: Optional[float]) -> str:
    """`12.345s`, or `?s` when the probe had no duration (MPEG-TS without a duration tag, a
    stream whose container and streams all omit it). Every writing tool prints the duration
    of what it wrote; formatting None with :.3f used to raise TypeError after a successful
    encode, in 25+ scripts."""
    return "?s" if value is None else f"{value:.3f}s"


def ntsc_rate(fps: float) -> float:
    """`fps` as the rate it is a rounding of: 23.976, 29.97, 47.952, 59.94 and 119.88 (what
    probe() reports, and what a caller types after `@`) are N * 1000 / 1001. Any other rate is
    returned as it is. timeline.exact_rate() reads the same five rates the same way."""
    whole = round(fps * 1.001)
    if whole in (24, 30, 48, 60, 120) and abs(fps - whole / 1.001) < 0.01 and abs(fps - whole) > 0.01:
        return whole * 1000 / 1001
    return fps


def parse_time(value: str, fps: Optional[float] = None) -> float:
    """Accept seconds ('12.5'), mm:ss ('1:30'), hh:mm:ss(.ms) ('00:01:30.250'), SRT '00:01:30,250',
    or -- when `fps` is given -- SMPTE non-drop-frame timecode 'hh:mm:ss:ff' ('00:01:30:15')."""
    v = value.strip().replace(",", ".")
    if not v:
        raise ValueError("empty time")
    if "@" in v:
        # 1.9: 'hh:mm:ss:ff@29.97' names the timecode's rate explicitly (docs/design-decisions.md,
        # time grammar); it overrides the source fps a tool passed in, and is meaningless without
        # the four-part form
        v, _, rate = v.rpartition("@")
        if "@" in v:
            raise ValueError(f"'{value}': only one @fps suffix is allowed")
        try:
            fps = float(rate)
        except ValueError:
            raise ValueError(f"bad @fps suffix in '{value}' (expected a number such as @29.97)")
        if not math.isfinite(fps) or fps <= 0:
            raise ValueError(f"bad @fps suffix in '{value}': the rate must be a positive, finite number")
        if len(v.split(":")) != 4:
            raise ValueError(f"'{value}': the @fps suffix belongs to an hh:mm:ss:ff timecode, not to seconds or mm:ss")
    parts = v.split(":")
    if len(parts) == 4:
        if fps is None or fps <= 0:
            raise MissingFpsError(f"'{value}' looks like an hh:mm:ss:ff SMPTE timecode, but no fps was given to convert its frame count to seconds (append @fps, e.g. {value}@29.97, or use seconds / mm:ss / hh:mm:ss.ms)")
        h, m, s, f = parts
        if "." in f:
            raise ValueError(f"bad SMPTE timecode: {value}")
        frame, whole_fps = int(f), int(round(fps))
        if not (0 <= frame < whole_fps):
            raise ValueError(f"bad SMPTE timecode '{value}': frame {frame} is out of range for {fps:g} fps (0-{whole_fps - 1})")
        # Non-drop-frame: the timecode counts whole_fps frames per timecode-second, so the real
        # time is the total frame count over the true rate (at 29.97 an hour of timecode is
        # 3596.4 s of video). This is exactly what fmt_smpte_time() inverts; before, the two
        # disagreed by ~0.1 % on the fractional NTSC rates and drifted apart over long files.
        total_frames = (int(h) * 3600 + int(m) * 60 + int(s)) * whole_fps + frame
        # at the picture's exact rate: probe()'s `fps` is rounded to three decimals, and frame 37
        # counted at 29.97 is 1.2345679 s, 1.2 microseconds past the frame at 37 * 1001 / 30000,
        # so a start read from 00:00:01:07 was the frame after it (ntsc_rate)
        return total_frames / ntsc_rate(fps)
    if len(parts) > 3:
        raise ValueError(f"bad time: {value}")
    total = 0.0
    for part in parts:
        try:
            total = total * 60 + float(part)
        except ValueError:
            # not the interpreter's "could not convert string to float: 'zz'" (review 9)
            raise ValueError(f"'{value}': not a time")
    # float() reads "nan", "inf" and "1e999": none of them is a time, and each got past the
    # comparisons that bound a time (nan compares false with everything)
    if not math.isfinite(total):
        raise ValueError(f"'{value}': not a time (it is not finite)")
    return total


def time_arg(value: str, flag: str, fps: Optional[float] = None,
             source: Optional[Dict[str, Any]] = None) -> float:
    """parse_time() for a command-line flag: SMPTE hh:mm:ss:ff resolves with the input's fps when
    the caller has one, and every parse failure is a `kind: input` refusal naming the flag (so
    `--json` callers get a failure document, never a traceback). `source` is the probe of the
    input the time is in when that is not the first one (a B-roll's --from, an overlay layer's
    --place range): the SMPTE hint then names that input's start timecode and length."""
    try:
        seconds = parse_time(value, fps)
    except MissingFpsError as e:
        die(f"{flag} {value!r}: {e}")
    except ValueError as e:
        die(f"{flag} {value!r}: {e} (use seconds, mm:ss, hh:mm:ss.ms, or hh:mm:ss:ff at the source's fps or with an explicit @fps suffix)")
    _remember_smpte_hint(value, flag, fps, seconds, source)
    return seconds


def _remember_smpte_hint(value: str, flag: str, fps: Optional[float], seconds: float,
                         source: Optional[Dict[str, Any]] = None) -> None:
    """An hh:mm:ss:ff time counts from the file's first frame (00:00:00:00), not from a camera's
    start timecode (docs/design-decisions.md, time grammar). When one reads past the end of a
    source that carries a start timecode it was almost certainly typed off the source's own
    burned-in or NLE timecode: keep a hint naming the frame it would be from the source's start,
    which die() adds to the refusal a tool then raises for the out-of-range time (#411). The
    grammar itself, and what a valid time means, are unchanged. A time in another input than the
    first is judged against that input's own timecode and length (#416 review)."""
    if source is not None:
        own = (source.get("timecode") or {}).get("value")
        tc = (own, source.get("duration")) if own else None
    else:
        tc = getattr(STATE, "source_timecode", None)
    text = value.strip().rpartition("@")[0] if "@" in value else value.strip()
    if not tc or len(text.split(":")) != 4:
        return
    start_tc, duration = tc
    rate = fps
    if "@" in value:
        try:
            rate = float(value.rpartition("@")[2])
        except ValueError:
            return
    try:
        start = parse_time(re.sub(r"[;.](\d+)$", r":\1", start_tc), rate)
    except ValueError:
        return
    if not duration or seconds <= duration or seconds < start:
        return
    within = seconds - start
    where = (f"{flag} {text} is {fmt_smpte_time(within, rate)} from the file's start"
             if within <= duration else f"{flag} {text} is past the end of this {duration:.3f} s file even so")
    prefix = (f"hh:mm:ss:ff times count from the file's first frame (00:00:00:00), not from the source's "
              f"start timecode {start_tc}: ")
    before = STATE.smpte_hint[len(prefix):] + "; " if STATE.smpte_hint and STATE.smpte_hint.startswith(prefix) else ""
    STATE.smpte_hint = prefix + before + where


def signed_time_arg(value: str, flag: str, fps: Optional[float] = None) -> float:
    """time_arg() for a flag that may also be negative (an offset, not a point in time): a single
    leading '-'/'+' is taken as the sign and the rest goes through the ordinary time grammar, so
    `--offset -00:00:02`, `--offset -1.5` and `--offset 0:02` all mean what they read as."""
    text = (value or "").strip()
    sign = 1.0
    if text[:1] in "+-":
        sign = -1.0 if text[0] == "-" else 1.0
        text = text[1:].strip()
    if not text:
        die(f"{flag} {value!r}: not a time (use seconds, mm:ss, hh:mm:ss.ms, or hh:mm:ss:ff)")
    return sign * time_arg(text, flag, fps)


def fmt_srt_time(seconds: float) -> str:
    if seconds < 0:
        seconds = 0.0
    ms = int(round(seconds * 1000))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def fmt_smpte_time(seconds: float, fps: float) -> str:
    """SMPTE non-drop-frame timecode 'hh:mm:ss:ff' for a real fps (not the fractional NTSC rates
    -- 29.97/59.94 need drop-frame counting to stay wall-clock accurate, which this does not do)."""
    if seconds < 0:
        seconds = 0.0
    whole_fps = int(round(fps))
    # the frames are counted at the rate parse_time() reads the same text at (29.97 as
    # 30000/1001): at 29.97 itself 06:00:00:00 came back as 05:59:59:29
    total_frames = int(round(seconds * ntsc_rate(fps)))
    frame = total_frames % whole_fps
    secs_total = total_frames // whole_fps
    h, rem = divmod(secs_total, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}:{frame:02d}"


def escape_filter_path(path: str, *, bind: bool = True) -> str:
    """Escape a file path for use as a filter option value (subtitles=, ass=, lut3d=file=, fontfile=, fontsdir=).

    A filter option value is parsed twice: the graph parser splits filters on `,` / `;` and options
    on `:`, then the filter's own option parser splits key=value pairs on `:` again. A character that
    must survive both passes needs two levels of escaping, so a Windows drive letter `D:/x.srt` is
    written `D\\\\:/x.srt`; with a single backslash the second pass still splits at the colon and
    ffmpeg reads `/x.srt` as the next option (`Unable to parse "original_size" option value`).
    On Windows backslashes are turned into forward slashes first (ffmpeg accepts them there); on
    POSIX a backslash is part of the name and is escaped through both passes (#408); `,`, `;`, `[` and `]` are graph-level characters and survive with
    one backslash. `'` is special: the graph parser also treats a quote as the start of a quoted
    token, so a single `\\'` is consumed by the first pass and "Ryo's Mac/cues.srt" reaches the
    filter as "Ryos Mac/cues.srt" (Unable to open ...). Three backslashes survive both passes
    (measured on 6.1 and 7.1 with subtitles=, ass= and lut3d=file=).

    `bind=False` escapes without recording the path as a plan input. The colour-emoji probe
    uses that: its SRT lives in a temp directory that is gone before any plan is written.
    """
    if bind and os.path.isfile(path) and path not in STATE.plan_inputs:
        STATE.plan_inputs.append(path)  # a plan binds subtitle/LUT/font files too (review 6)
    p = str(Path(path))
    if _on_windows():
        p = p.replace("\\", "/")
    else:
        # on POSIX a backslash is a character of the name (#408): turning it into `/` opened a
        # different path, so it is escaped through both passes instead
        p = p.replace("\\", "\\\\\\\\")
    # A filter that opens its file through libavformat (subtitles=, metadata=print:file=) reads a
    # relative `a:b.srt` or `d:e/c.srt` as protocol `a` or `d` ("Protocol not found"), and Path()
    # above has dropped the `./` a caller wrote to say it is a file (#558). A relative path whose
    # first segment has a colon gets it back; a filter that opens with fopen (lut3d, drawtext,
    # ssim's stats_file) reads `./name` as the same file. An absolute path and a Windows path
    # with a drive (`C:/x`, `C:x`) are left as they are: the drive's colon is not a scheme.
    pure = PureWindowsPath(p) if _on_windows() else PurePosixPath(p)
    if ":" in p.split("/", 1)[0] and not pure.is_absolute() and not pure.drive:
        p = "./" + p
    p = p.replace(":", "\\\\:")
    p = p.replace("'", "\\\\\\'")
    for ch in (",", ";", "[", "]"):
        p = p.replace(ch, "\\" + ch)
    # the graph parser trims unescaped whitespace at either end of a value (#408: a relative
    # " lead.srt" opened "lead.srt"); both passes keep an escaped one
    lead = len(p) - len(p.lstrip())
    trail = len(p) - len(p.rstrip())
    if lead or trail:
        body = p[lead:len(p) - trail] if trail else p[lead:]
        p = "".join("\\\\" + c for c in p[:lead]) + body + "".join("\\\\" + c for c in p[len(p) - trail:] if trail)
    return p


# ------------------------------------------------------- both streams on one clock (#409)
#
# ffmpeg shifts every stream of an input by one constant (the file's start_time), so a filter graph
# sees a sound that starts 0.3 s after its picture at 0.3. A per-stream `PTS-STARTPTS` moved that
# sound 0.3 s early. cut.py's re-cut is the reference: both streams are cut on the same bounds,
# shifted by the same constant, and the audio is padded to the origin
# (docs/design-decisions.md, "Both streams of a segment shift by one constant").

def stream_starts(meta: Optional[Dict[str, Any]]) -> Tuple[float, float]:
    """Where the video and the audio start on the clock a filter graph reads the input on (each
    stream's start_time minus the file's); 0.0 for a stream whose start is unknown."""
    from _common.emit import file_origin
    meta = meta or {}
    origin = file_origin(meta)
    out = []
    for kind in ("video", "audio"):
        start = (meta.get(kind) or {}).get("start_time")
        out.append(float(start) - origin if isinstance(start, (int, float)) else 0.0)
    return out[0], out[1]


# Pads a sound that starts after the clock's 0 with silence from 0 (#409's rule for a re-encode),
# then cuts the result into frames of 4096 samples (p=0: the last one is not padded, so the length
# is the sound's). On FFmpeg 9 the pad handed the encoder the lead and the sound in one frame, and
# the FLAC encoder, which takes frames as they come, refused it ("invalid block size: 111305",
# #554's CI on 9.0.2; 6.1.1 splits the frames itself, so this was not seen locally)
PAD_SOUND_FROM_ZERO = "aresample=async=1:first_pts=0,asetnsamples=n=4096:p=0"


def late_sound_lead(meta: Optional[Dict[str, Any]]) -> float:
    """How long after the file's origin the sound starts, when a sound-only output has to carry
    that as silence: 0.0 for a lead of half a millisecond or less (sync.py's bound) and for a
    source whose start is unknown. A WAV or FLAC has no start time, and an .m4a's is an edit a
    decoder does not pad, so a sound-only output written without the lead plays that much early
    against the picture it came from (audio.py, loudness.py; cut.py --accurate pads it too, A46)."""
    lead = stream_starts(meta)[1]
    return lead if lead > 0.0005 else 0.0


# The size of the decoded clip above which a tool that holds every frame (reverse, a boomerang)
# says `memory_heavy`.
HELD_FRAMES_WARN_BYTES = 2 * 1024 ** 3


def held_frames_bytes(v: Dict[str, Any], frames: float) -> int:
    """About how many bytes `frames` decoded frames of the picture `v` (a probe()'s `video`) take:
    the picture's size, its chroma planes (4:2:0 1.5x, 4:2:2 2x, 4:4:4 3x, an alpha plane one
    more) and 2 bytes a sample above 8 bits. The one estimate reverse.py and loop.py --boomerang
    warn from: reverse.py's was the clip's duration alone, so a 30 s 4K60 clip (tens of GB) got
    no warning and a 61 s 320x180 one did (A174)."""
    pix = str(v.get("pix_fmt") or "")
    planes = 3.0 if "444" in pix or pix.startswith(("gbr", "rgb", "bgr")) else 2.0 if "422" in pix else 1.5
    if pix.startswith(("yuva", "gbra", "rgba", "bgra", "argb", "abgr", "ya")):
        planes += 1.0
    depth = 2 if (v.get("bit_depth") or 8) > 8 else 1
    return int((v.get("width") or 0) * (v.get("height") or 0) * planes * depth * max(0.0, frames))


def frame_rate(meta: Optional[Dict[str, Any]]) -> float:
    """The video's frame rate as cut.py's grid takes it: r_frame_rate, else fps; 0.0 when unknown."""
    v = (meta or {}).get("video") or {}
    try:
        num, _, den = str(v.get("r_frame_rate") or "").partition("/")
        rate = float(num) / float(den or 1)
    except (ValueError, ZeroDivisionError):
        rate = 0.0
    if not 0 < rate <= 240:  # a time base (90000/1), not a rate
        rate = float(v.get("fps") or 0.0)
    return rate


def frame_durations(meta: Optional[Dict[str, Any]], rate: float) -> str:
    """An `fps` filter at the video's own rate (r_frame_rate as a fraction when it is one), the
    last filter of a graph whose frames sit on that rate's grid: it moves none of them, and gives
    each frame its duration back. From FFmpeg 7.0 setpts sets every frame's duration to 0 and
    leaves the frame rate unknown, so the last frame of a graph that ends after a setpts (av_trim)
    was written with no duration and the picture read a frame short (3.967 s for 120 frames)."""
    v = (meta or {}).get("video") or {}
    try:
        q = Fraction(str(v.get("r_frame_rate") or ""))
    except (ValueError, ZeroDivisionError):
        q = None
    if q is not None and abs(float(q) - rate) < 1e-6:
        return f"fps={q.numerator}/{q.denominator}"
    return f"fps={rate:.6f}"


# a time written in milliseconds is the frame it reads back to (#653): the nearest frame when that
# is within half a millisecond either way, never one before the first; any other time is itself.
# For a position the caller names (a cut point, --at, a segment bound), not for a length
def on_frame(t: float, v0: float, rate: float) -> float:
    return g if rate and (n := round((t - v0) * rate)) >= 0 and abs((g := v0 + n / rate) - t) <= 0.0005 else t


def grid_at_or_after(t: float, v0: float, rate: float) -> float:
    """The time of the first frame at or after `t` on a constant-rate grid starting at `v0`."""
    if not rate:
        return t
    return v0 + math.ceil((t - v0) * rate - 1e-6) / rate


def frame_window(start: Optional[float], end: Optional[float], meta: Optional[Dict[str, Any]],
                 half_open: bool = False) -> Optional[Tuple[Optional[float], Optional[float]]]:
    """The two times a filter compares a frame's `t` with so that a window from `start` to `end`
    seconds of `meta`'s picture holds the frames asked: half a frame before the first frame at or
    after `start`, and half a frame after the last frame at or before `end` (`half_open`: half a
    frame before the first frame at or after `end`, which is then outside). A bound written as
    the time itself is compared with `t` on the frame it names: `{:.3f}` put frame 37 of a
    30000/1001 picture (1.234567 s) after a start of "1.235", and `t` is a double (pts x time
    base) that is not always the number the text reads as (the frame at 1.4 s of a 25 fps MP4 is
    not `<= 1.400`; FFmpeg 6.1.1). The grid is the one grid_at_or_after() counts on. None when
    there is no grid to count on (no rate: a dry run's pending input; a picture probe() suspects
    of a variable rate): the caller keeps the text it had. A bound of None stays None."""
    v = (meta or {}).get("video") or {}
    rate = frame_rate(meta)
    if not rate or v.get("variable_frame_rate_suspected"):
        return None
    v0, half = stream_starts(meta)[0], 0.5 / rate
    lo = None if start is None else grid_at_or_after(start, v0, rate) - half
    if end is None:
        hi = None
    elif half_open:
        hi = grid_at_or_after(end, v0, rate) - half
    else:
        hi = v0 + math.floor((end - v0) * rate + 1e-6) / rate + half
    return lo, hi


def window_expr(start: Optional[float], end: Optional[float], meta: Optional[Dict[str, Any]],
                half_open: bool = False) -> str:
    """The expression that is true on the frames of frame_window(): `between(t,LO,HI)`, or
    `gte(t,LO)` with no end. With no start the window opens at 0, as it always did. Without a
    grid it is the millisecond text the tools wrote before."""
    bounds = frame_window(start, end, meta, half_open)
    if bounds is None:
        lo = f"{start:.3f}" if start is not None else "0"
        return f"gte(t,{lo})" if end is None else f"between(t,{lo},{end:.3f})"
    lo = f"{bounds[0]:.6f}" if bounds[0] is not None else "0"
    return f"gte(t,{lo})" if bounds[1] is None else f"between(t,{lo},{bounds[1]:.6f})"


def windowed_overlay_x(x: Any, window: str) -> str:
    """An `overlay` x that puts the layer at `x` on the frames `window` is true on and off the
    picture on every other frame. overlay's `enable` is not the main picture's alone: FFmpeg
    evaluates it on each frame either input hands over, the layer's next one included, so a still
    looped at 25 fps over a 30000/1001 picture was drawn from the frame before the window's
    first to the frame before its last (36-66 for 37-67; FFmpeg 6.1.1). The position is
    evaluated once per output frame with the main picture's `t`."""
    return f"'if({window},{x},-w)'"


def av_trim(start: float, end: Optional[float], rate: float = 0.0, fill_gaps: bool = False) -> Tuple[str, str]:
    """The video and the audio filters that cut one segment [start, end) of the graph clock out of
    both streams and shift both by the same constant, so an offset between them survives; `end`
    None runs to the stream's end. The picture's trim sits half a frame before each bound (the
    bounds are frame times: grid_at_or_after), so no FFmpeg version rounds a boundary frame in or
    out; the audio is padded to the segment's origin when it starts later. `fill_gaps` also fills
    every later gap in the sound with silence, however short (aresample's default only fills one
    longer than 0.1 s and stretches the sound by a sample a second for the rest)."""
    half = 0.5 / rate if rate else 0.0
    pad = "aresample=async=1:min_hard_comp=0.001:first_pts=0" if fill_gaps else "aresample=async=1:first_pts=0"
    vend = f":end={end - half:.6f}" if end is not None else ""
    aend = f":end={end:.6f}" if end is not None else ""
    return (f"trim=start={start - half:.6f}{vend},setpts=PTS-{start:.6f}/TB",
            f"atrim=start={start:.6f}{aend},asetpts=PTS-{start:.6f}/TB,{pad}")


def conform_filter(samples: int, rate: int) -> str:
    """Pad with silence or trim to exactly `samples` at `rate` (#478): counted in samples, not in
    seconds written to the millisecond, which left a result up to 24 samples (48 kHz) off. The
    aformat pins the rate the count is in, so a resampler FFmpeg inserts sits ahead of the count."""
    head = f"aformat=sample_rates={rate}," if rate else ""
    return f"{head}apad=whole_len={samples},atrim=end_sample={samples}"


def conform_to_length(length: float, rate: int) -> str:
    """Pad with silence or trim a track to `length` seconds of a timeline that starts at 0, to the
    sample (#478, #493). The count is of samples, and sound that starts after 0 keeps its start
    (apad and atrim=end_sample do not move timestamps): N samples from 0.3 s end 0.3 s past
    `length`. The trim on the timestamp ends it there; half a sample of slack keeps the Nth sample
    of a track that starts at 0. audio.py, grid.py, broll.py and multicam.py end their sound with
    this; `atrim=duration={length:.3f}` cut 59244 samples (48 kHz) to 59232."""
    return conform_filter(round(length * rate), rate) + f",atrim=end={length + 0.5 / rate:.6f}"


def conform_output_t(length: float, rate: int) -> str:
    """The output `-t` beside conform_to_length(): `-t {length:.3f}` would cut the conformed sound
    back to the millisecond, so the limit sits half a sample past the last one."""
    return f"{length + 0.5 / rate:.6f}"


def length_output_t(length: float, rate: Optional[int], runs_on: bool = False) -> str:
    """The output `-t` of a tool that leaves the sound's end to it (overlay.py, waveform.py,
    loop.py, sync.py --replace-audio): the millisecond text they always wrote unless it cuts
    samples off the track at `rate` (`-t 1.234` wrote 59244 samples at 48 kHz as 59232), and then
    the length to the microsecond, which FFmpeg rounds to the nearest sample. `runs_on` is for
    sound that goes on past the length (an endless apad, a loop's next repeat): there the
    millisecond text is also left when it rounds up (`-t 1.235` wrote 59261 as 59280). No half
    sample of slack as in conform_output_t(): this `-t` ends the picture too, and with the slack a
    layer's frame that starts exactly at the end came through on a 1/60000 or 1/90000 time base
    (FFmpeg 6.1.1). A rate of 0 or None (no sound, a dry run's pending input) keeps the
    millisecond text."""
    text = f"{length:.3f}"
    if rate:
        def names(micro: int) -> int:
            # the samples FFmpeg makes of a -t of `micro` microseconds: a rescale that rounds a
            # half up, where Python's round() takes it to the even count (0.005 s at 44.1 kHz is
            # 220.5 samples: 221 written, round() says 220)
            return (micro * rate + 500_000) // 1_000_000
        written, asked = names(round(float(text) * 1_000_000)), round(length * rate)
        if written < asked or (runs_on and written != asked):
            # the microsecond text is a rounding too (2.00001042 s is 96001 samples at 48 kHz and
            # "2.000010" names 96000): the microsecond nearest the length, moved by whole
            # microseconds until it names the count asked. A microsecond is a twentieth of a
            # sample at 48 kHz, so this is a step or two, not conform_output_t()'s half sample
            micro = round(length * 1_000_000)
            while names(micro) < asked:
                micro += 1
            while names(micro) > asked:
                micro -= 1
            return f"{micro // 1_000_000}.{micro % 1_000_000:06d}"
    return text


def silence_filter(rate: Optional[int], lead: Optional[float] = None, tail: Optional[float] = None) -> str:
    """Silence of `lead` seconds ahead of a track and/or `tail` seconds after it (pad.py,
    freeze.py). An amount in whole milliseconds is written as it always was (`adelay=MS:all=1`,
    `apad=pad_dur=S.mmm`), the millisecond rounded, not cut: int(1.001 * 1000) is 1000. One that
    is not is counted in samples at `rate`, pinned by an aformat as in conform_filter():
    `adelay=234` and `apad=pad_dur=0.234` for 0.23425 s left the sound 12 samples short at 48 kHz.
    A rate of 0 or None (a dry run's pending input) keeps the millisecond form."""
    amounts = [v for v in (lead, tail) if v is not None]
    if rate and any(round(v * rate) != round(round(v, 3) * rate) for v in amounts):
        parts = [f"aformat=sample_rates={rate}"]
        if lead:
            parts.append(f"adelay={round(lead * rate)}S:all=1")
        if tail:
            parts.append(f"apad=pad_len={round(tail * rate)}")
        return ",".join(parts)
    parts = []
    if lead is not None:
        parts.append(f"adelay={round(lead * 1000)}:all=1")
    if tail is not None:
        parts.append(f"apad=pad_dur={tail:.3f}")
    return ",".join(parts)


def tpad_length(seconds: float, meta: Optional[Dict[str, Any]]) -> float:
    """How long the picture `tpad=start_duration={seconds:.3f}` puts ahead of `meta`'s clip is:
    tpad adds whole frames, the nearest count to the text it is given (0.23425 s at 25 fps is
    written "0.234" and becomes 6 frames, 0.240 s). A sound delayed by `seconds` itself would
    start up to half a frame before or after the picture it belongs to; delayed by this length it
    moves with it (both streams of a clip shift by one constant: #409). `seconds` as it is when
    there is no rate to count frames at (a dry run's pending input) or probe() suspects a
    variable one."""
    v = (meta or {}).get("video") or {}
    rate = frame_rate(meta)
    if not rate or v.get("variable_frame_rate_suspected"):
        return seconds
    try:
        exact = Fraction(str(v.get("r_frame_rate") or ""))
    except (ValueError, ZeroDivisionError):
        exact = None
    if exact is None or abs(float(exact) - rate) > 1e-6:
        exact = Fraction(rate).limit_denominator(1001)
    frames = math.floor(Fraction(f"{seconds:.3f}") * exact + Fraction(1, 2))  # a half rounds up, as av_rescale does
    return float(frames / exact)


def av_clip_length(meta: Optional[Dict[str, Any]], fps: float) -> float:
    """The one length a clip holds once both streams start at its first frame (av_trim from the
    video's start): the video's, or where the sound ends when it runs more than a frame past the
    picture (narration is never cut; an AAC tail adds no frame). The container duration is only the
    fallback when the video's length is unknown (a pending input)."""
    meta = meta or {}
    v = (meta.get("video") or {}).get("duration")
    a = (meta.get("audio") or {}).get("duration")
    if not v:
        return input_length(meta)  # a file that states no length at all is refused, not 0 s long (#491)
    if a:
        v0, a0 = stream_starts(meta)
        a = a + a0 - v0  # where the sound ends, counted from the first frame
    if a and fps and a > v + 1.0 / fps:
        return a
    return v


def cfr_args(meta: Optional[Dict[str, Any]], fps: Optional[float] = None) -> List[str]:
    """Force a constant frame rate on output when the source looks VFR (or fps is given).

    VFR sources (phone/screen recordings) drift against audio after cuts and joins,
    so every re-encoding script passes this to conform them automatically.
    """
    v = (meta or {}).get("video") or {}
    if fps is None and not v.get("variable_frame_rate_suspected"):
        return []
    rate = fps or v.get("fps") or 30.0
    rate = round(rate) if abs(rate - round(rate)) < 0.02 else rate
    # a rate the caller asked for relabels the start timecode, counted at the new rate (#470:
    # proxy/denoise/crop/redact/sphere/straighten --fps 50 kept 01:00:00:12, a 25 fps label)
    from _common.timeline import output_timecode_args
    relabel = output_timecode_args(meta, 0.0, rate) if fps and v.get("fps") and abs(float(fps) - float(v["fps"])) > 0.01 else []
    return ["-fps_mode", "cfr", "-r", f"{rate:g}"] + relabel


def cfr_filter(meta: Optional[Dict[str, Any]], fps: Optional[float] = None, seek: float = 0.0) -> str:
    """The `fps` filter that puts the picture on the grid cfr_args() delivers, as the last filter of
    the video chain; "" when cfr_args() forces no rate. The encoder line's `-fps_mode cfr -r` alone
    let a frame fall up to about two frames behind its slot before it dropped one, so a VFR clip
    conformed at its average rate showed its picture up to 56 ms after its sound (#512); the
    filter puts each frame on the slot its time rounds to (within half a frame of it; a slot in a
    gap keeps the frame before it). The encoder line keeps cfr_args(), which then
    moves no frame.

    `seek` is an output-side `-ss` that follows the conform (cut.py's and fit.py --method trim's
    margin after an input seek): the grid is laid from it instead (#538). The filter lays its grid
    from the first frame on the clock, its output's time base is one frame, and the output seek
    then landed between two slots, which the encoder line's rate rounded again: on a 27 fps
    average clip `cut.py --start 0.45` put its picture 24 ms after its sound, 33 ms at 0.2. The
    picture is moved so the seek is its 0, conformed from there (`start_time=0`: a frame takes the
    slot its time rounds to and stays until the next frame's slot, so the last frame before the
    seek fills the slots up to the first frame after it), and moved back on a
    microsecond time base, so the seek lands on a slot and the output's frames sit on the grid
    from 0. The setpts after the conform leaves its frames no duration from FFmpeg 7.0; the
    encoder line's `-fps_mode cfr`, which cfr_args() always gives with this filter, sets each to
    one frame."""
    args = cfr_args(meta, fps)
    if not args:
        return ""
    rate = args[args.index("-r") + 1]
    if seek > 0:
        return (f"setpts=PTS-{seek:.6f}/TB,fps={rate}:start_time=0,"
                f"settb=AVTB,setpts=PTS+{seek:.6f}/TB")
    return f"fps={rate}"


def with_cfr(chain: str, meta: Optional[Dict[str, Any]], fps: Optional[float] = None) -> str:
    """`chain` (a -vf value or one filtergraph chain) with cfr_filter() appended when there is one.
    A -vf value that is a graph of its own (drawn_chain()'s split/maskedmerge) gets it first
    instead: maskedmerge, like overlay, ends its output at its last frame's start, and an fps
    filter after it lost the last frame (graphics.py --template chapter: 3.963 s of 4)."""
    return chain_with_rate(chain, cfr_filter(meta, fps))


def chain_with_rate(chain: str, rate_filter: str) -> str:
    """`chain` with an `fps` filter `rate_filter` placed as with_cfr() places cfr_filter(): last in
    a plain chain, first in a -vf that is a graph of its own (fit/export's blur pad, a drawn pad
    with chroma), whose overlay or maskedmerge ends its output at its last frame's start on FFmpeg
    6.1 and lost the last frame to an fps filter after it. For a rate that is not cfr_args()'s
    own (export.py's preset and platform rates)."""
    if not rate_filter:
        return chain
    if ";" in chain:
        return f"{rate_filter},{chain}"
    return f"{chain},{rate_filter}" if chain else rate_filter


def graph_with_cfr(graph: str, label: str, meta: Optional[Dict[str, Any]],
                   fps: Optional[float] = None) -> Tuple[str, str]:
    """A -filter_complex graph and the video output label to map, with cfr_filter() after that
    label when there is one: (graph + ";[v]fps=R[vcfr]", "[vcfr]"), else both unchanged."""
    f = cfr_filter(meta, fps)
    if not f:
        return graph, label
    bare = label.strip("[]")
    return f"{graph};[{bare}]{f}[{bare}cfr]", f"[{bare}cfr]"


def cfr_at_input(graph: str, meta: Optional[Dict[str, Any]], fps: Optional[float] = None, src: str = "[0:v]",
                 origin: Optional[float] = None) -> str:
    """A -filter_complex graph with cfr_filter() on its main picture as it is decoded (`src`, which
    the graph reads once), for a graph that composites onto that picture and moves no frame in
    time. After an overlay the conform comes too late: FFmpeg 6.1's overlay ends its output at its
    last frame's start, so an fps filter there lost the last frame (3.963 s of a 4 s picture).
    With `origin` (where the picture starts on the graph's clock, stream_starts()) the picture is
    moved to start at 0 ahead of the conform, so the grid is laid from its first frame, and the
    conformed frames get a microsecond time base, for a graph that cuts the picture on that grid
    (freeze.py, #523): the caller counts the picture's times from its own start. The fps
    filter's grid starts at the clock's 0, so a picture that starts 50 ms in was cut a frame off
    the times computed from its start, and its output's time base is one frame, to which `trim`
    rescales its bound (a half-frame bound written to the microsecond, 3.907407 at 27 fps, became
    the frame at 3.888889 and cut it). The picture is not moved back after the conform: from
    FFmpeg 7.0 setpts leaves its output frames no duration and no rate, and a tpad after it (the
    hold) cloned nothing: 109 frames for 135 on 7.1."""
    f = cfr_filter(meta, fps)
    if not f:
        return graph
    if graph.count(src) != 1:
        # a graph that read the picture twice, or not at all, would go unconformed or not parse
        raise ValueError(f"cfr_at_input: the graph reads {src} {graph.count(src)} times, not once")
    if origin is not None:
        f = f"setpts=PTS-{origin:.6f}/TB,{f},settb=AVTB" if origin else f"{f},settb=AVTB"
    return f"{src}{f}[cfrin];" + graph.replace(src, "[cfrin]")


def atempo_lead(sample_rate: Any) -> int:
    """How many samples of its input `atempo` leaves out at the start: half its window, which is
    the power of two at or above sample_rate / 24 (2048 at 44.1 and 48 kHz, so 1024 samples, 21 ms
    at 48 kHz). Its output opens on the sample half a window in (measured at 8, 22.05, 32, 44.1,
    48 and 96 kHz on FFmpeg 6.1.1), so every sound after it is that much early: speedramp.py's beeps
    came 21 ms early at 1x and 40 ms at 0.5x, and fit.py --method speed's the same (#523). 0 when
    the rate is not known (a dry run's pending input)."""
    try:
        rate = int(sample_rate or 0)
    except (TypeError, ValueError):
        return 0
    window = rate // 24
    if window < 1:
        return 0
    pot = 1 << (window.bit_length() - 1)
    return (pot * 2 if pot < window else pot) // 2


def atempo_chain_with_lead(stages: List[str], sample_rate: Any) -> str:
    """`atempo` stages (each value as written) led by silence and trimmed after, so the output
    keeps the input's timing from its first sample: a beep at 0.5 s of a 1x stage came out at
    0.479 s (FFmpeg 6.1.1). Each stage leaves out atempo_lead() samples of its own input, which
    are the earlier stages' tempo product times that many of the chain's input, so one lead of
    their sum goes in front of the first stage: an `adelay` between two stages made FFmpeg 6.1.1
    fail a graph that joins the result with `concat` ("Invalid data found when processing
    input", speedramp.py with a 0.25x segment). That lead alone put the chain's first window,
    which atempo fades in, over the input's first 21 ms: a 10 ms attack there came out 7 dB down
    at 1x and was gone at 2x (#541 review). So one whole window more of silence goes in front
    (as many of the chain's input samples as leave a window of it ahead of every stage), and
    that much of the output, at the chain's tempo, is cut off again and its timestamps moved
    back by it, so a track that starts after 0 keeps its start. The bare stages when the rate is
    not known (a dry run's pending input)."""
    lead = atempo_lead(sample_rate)
    chain = ",".join(f"atempo={value}" for value in stages)
    if not lead:
        return chain
    total, product, widest = 0.0, 1.0, 1.0
    for value in stages:
        total += lead * product
        product *= float(value)
        widest = max(widest, product)
    extra = round(2 * lead * widest)  # a window of silence ahead of the stage that shrinks it most
    cut = round(extra / product)
    return (f"adelay={round(total) + extra}S:all=1,{chain},"
            f"atrim=start_sample={cut},asetpts=PTS-{cut}/SR/TB")


def delivered_rate(meta: Optional[Dict[str, Any]], fps: Optional[float] = None) -> Optional[float]:
    """The constant rate cfr_args() forces on the output (its -r), or None when it forces none and
    the output keeps the source's rate -- what a start timecode is counted at
    (timeline.output_timecode_args)."""
    args = cfr_args(meta, fps)
    return float(args[-1]) if args else None


# how far before a cut an input seek lands, so a start inside the B-frame reorder delay before a
# keyframe still decodes from the keyframe BEFORE it; the margin is dropped on the output side
# (cut.py, sync.py --trim-second)
SEEK_MARGIN = 1.0


# ------------------------------------------------------- VideoToolbox (--hw)
#
# CRF -> VideoToolbox -q:v (1-100, higher = better): at each CRF the highest -q:v whose SSIM matched
# the CPU line's (x264/x265 medium) across the clips of tests/bench_vt.py -- synthetic CG, fractal
# and grain plus iPhone 17 Pro 1080p (M3, FFmpeg 9.0.2), so a GPU encode never measures below the
# CPU one. HDR has its own curve: its CPU line is x265 Main10 at CRF+2, and the Main10 VideoToolbox
# line needs ~11-15 less -q:v for that SSIM (the SDR curve wrote HLG phone footage at 6-8x x265's
# bytes). Matched quality costs 1.1-2.9x the bytes of x264/x265 on SDR and 1.9-3.5x on HDR --
# which is why --hw is opt-in and delivery presets stay on the CPU (docs/design-decisions.md).


def vt_quality(codec: str, crf: int, hdr: bool = False) -> int:
    base, slope = (63.0, 1.6) if hdr else (75.0, 2.2) if codec == "h264" else (78.0, 2.0)
    return max(1, min(100, int(round(base - slope * (crf - 18)))))


def _vt_bt709(codec: str) -> List[str]:
    """BT.709 tags for a VideoToolbox SDR encode. From FFmpeg 7.1 the -colorspace output options
    drive a real matrix conversion on an untagged source (see bt709_tag_args), and VideoToolbox has
    no -x264-params VUI route; a bitstream filter writes the VUI after encoding, which the filter
    graph never sees (measured: 49.9 dB PSNR tag-neutral vs 23.8 dB through the output options).
    It is used on every version, not only >= 7.1: it is tag-only everywhere, and a git build of
    7.1 reads as (7, 0) from its libavutil major, which would otherwise take the converting path."""
    return ["-bsf:v", f"{codec}_metadata=colour_primaries=1:transfer_characteristics=1:matrix_coefficients=1"]


def source_transfer(v: Dict[str, Any]) -> str:
    """The transfer a 10-bit re-encode of a BT.2020 / HDR source is tagged with: the source's own
    tag, or, when it has none, what probe() read it as. BT.2020 primaries with no transfer tag are
    `hdr_format` "BT.2020 SDR" (not an HDR signal), so they are tagged bt2020-10, the SDR curve
    BT.2020 defines; through 3.8.8 every such re-encode came out tagged HLG (audit A153). An
    HDR signal with no transfer tag (Dolby Vision whose base layer is untagged) keeps the HLG
    default it always had."""
    return v.get("color_transfer") or ("arib-std-b67" if v.get("hdr_signal") else "bt2020-10")


def _vt_args(codec: str, crf: int, meta: Optional[Dict[str, Any]], keep_bt709: bool) -> Optional[List[str]]:
    """VideoToolbox encoder options for `codec`, or None (with a note in STATE.hw_notes) when the
    request stays on the CPU: no VideoToolbox encoder for the codec, this machine cannot, or the
    ffmpeg build lacks it."""
    name = {"h264": "h264_videotoolbox", "hevc": "hevc_videotoolbox", "prores": "prores_videotoolbox"}.get(codec)
    reason = None if name else f"no VideoToolbox encoder for {codec}"
    reason = reason or hw_platform_reason()
    if not reason and name not in ffmpeg_encoders():
        unread = ffmpeg_list_error("encoders")
        # an encoder list that could not be read says nothing about the build: name the read
        # failure, not a missing encoder (the read itself is a ffmpeg_list_unreadable warning)
        reason = (f"{name} could not be confirmed (this ffmpeg build's encoder list could not be read: {unread})" if unread
                  else f"this ffmpeg build has no {name}")
    if reason:
        note = f"{reason}; encoded on the CPU"
        if note not in STATE.hw_notes:
            STATE.hw_notes.append(note)
        return None
    v = (meta or {}).get("video") or {}
    hdr = bool(v.get("bt2020_or_hdr"))
    hdr_tags = ["-colorspace", hdr_line_matrix(v), "-color_primaries", v.get("color_primaries") or "bt2020",
                "-color_trc", source_transfer(v)]
    if codec == "prores":
        return ["-c:v", name, "-profile:v", "hq", "-pix_fmt", "p210le"] + (hdr_tags if hdr else [])
    # The HDR curve was fitted on the Main10 HEVC line; an 8-bit H.264 line (an export preset on
    # an HDR source) replaces x264 at the same CRF and keeps the H.264 curve.
    q = str(vt_quality(codec, crf, hdr and codec == "hevc"))
    if codec == "h264":
        return ["-c:v", name, "-q:v", q, "-profile:v", "high", "-pix_fmt", "yuv420p", "-movflags", "+faststart"] + \
            (_vt_bt709("h264") if keep_bt709 else [])
    if hdr:
        # Measured on FFmpeg 9.0: HDR10 mastering-display and content-light side data carry through
        # hevc_videotoolbox exactly as through libx265 (test_hw_hdr10_side_data_survives).
        return ["-c:v", name, "-q:v", q, "-profile:v", "main10", "-pix_fmt", "p010le", "-tag:v", "hvc1"] + hdr_tags + ["-movflags", "+faststart"]
    return ["-c:v", name, "-q:v", q, "-pix_fmt", "yuv420p", "-tag:v", "hvc1", "-movflags", "+faststart"] + \
        (_vt_bt709("hevc") if keep_bt709 else [])


# An LGPL ffmpeg (the kind a desktop app ships) has VideoToolbox but neither libx264 nor libx265.
# There the CPU line cannot run at all, so VideoToolbox is the only encoder there is and takes the
# job without --hw (#314). Only when the encoder list was read and lacks the CPU encoder, and only
# where --hw would run; a build that has libx264 never gets here (docs/design-decisions.md).
_VT_FOR_CPU = {"libx264": "h264_videotoolbox", "libx265": "hevc_videotoolbox"}


def _vt_in_place_of(cpu_encoder: Optional[str]) -> Optional[str]:
    """The VideoToolbox encoder that takes over from `cpu_encoder` because this ffmpeg build lacks
    it, else None: not when --hw already decided, nor under an explicit --no-hw (the caller asked
    for the CPU), nor on a machine VideoToolbox cannot run on. The platform is asked before the
    encoder list, so Linux and Windows never read it for this. An empty list (ffmpeg's could not
    be read) proves nothing is missing."""
    vt = _VT_FOR_CPU.get(cpu_encoder or "")
    if vt is None or STATE.hw or STATE.hw_source == "flag" or hw_platform_reason() is not None:
        return None
    have = ffmpeg_encoders()
    return vt if have and cpu_encoder not in have and vt in have else None


def _note_vt_in_place_of(cpu_encoder: str, vt: str) -> None:
    if cpu_encoder not in STATE.hw_auto:
        STATE.hw_auto.append(cpu_encoder)
    note = f"{cpu_encoder} is not in this ffmpeg build, so this encode ran on {vt} (VideoToolbox) instead"
    if note not in STATE.hw_notes:
        STATE.hw_notes.append(note)


def _maybe_hw(codec: str, crf: int, meta: Optional[Dict[str, Any]], keep_bt709: bool, cpu: List[str]) -> List[str]:
    """`cpu` unchanged unless --hw / $FFMPEG_SKILL_HW is on and VideoToolbox can take `codec`, or
    unless the build has no CPU encoder for it (_vt_in_place_of); the --hw swap is remembered so
    run() can put the CPU line back if the GPU refuses the job. A build without the CPU encoder
    has no line to put back, so nothing is remembered for it."""
    cpu_encoder = cpu[cpu.index("-c:v") + 1] if "-c:v" in cpu else None
    vt_name = _vt_in_place_of(cpu_encoder)
    if not STATE.hw and vt_name is None:
        return cpu
    vt = _vt_args(codec, crf, meta, keep_bt709)
    if vt is None:
        return cpu
    if vt_name:
        _note_vt_in_place_of(cpu_encoder or "", vt_name)
        return vt
    # a copy: a caller that edits the returned line in place (export.py strips -movflags) must
    # not edit the recorded slice with it, or restate_last_swap() never sees the line as built
    STATE.hw_swaps.append((list(vt), cpu))
    return vt


_CPU_TO_CODEC = {"libx264": "h264", "libx265": "hevc", "prores_ks": "prores"}


def hw_preset_video(video: List[str], meta: Optional[Dict[str, Any]], *, bt709: bool) -> List[str]:
    """export.py's fixed-preset encoder line moved to VideoToolbox (same codec, the preset's -crf
    mapped to -q:v, its -r kept); unchanged -- with the reason noted -- when that cannot apply.
    Called under --hw, and for a preset whose libx264/libx265 this build lacks (_vt_in_place_of),
    where it is the only encoder there is; otherwise it returns `video` untouched.

    `bt709`: whether export.py tags this preset's CPU line BT.709 (every fixed preset but prores,
    whose master keeps the source's tags). The VideoToolbox line writes the format the CPU preset
    writes: an h264/hevc preset is 8-bit with BT.709 tags whatever the source (on an HDR source it
    says so in a note, as without --hw), so it is built as for an SDR source -- not the Main10 HDR
    line, which would make the GPU file and its CPU fallback different formats."""
    enc = video[video.index("-c:v") + 1] if "-c:v" in video else None
    codec = _CPU_TO_CODEC.get(enc or "")
    if codec is None:
        return video
    vt_name = _vt_in_place_of(enc)
    if not STATE.hw and vt_name is None:
        return video
    crf = int(video[video.index("-crf") + 1]) if "-crf" in video else 18
    vt = _vt_args(codec, crf, meta if codec == "prores" else None, bt709)
    if vt is None:
        return video
    vt = strip_movflags(vt)  # export adds it
    if "-r" in video:
        vt += ["-r", video[video.index("-r") + 1]]
    if vt_name:
        _note_vt_in_place_of(enc or "", vt_name)
        return vt
    # the CPU line export would have written: the preset's own options plus the BT.709 tags export
    # adds to it (only to the CPU line), so a GPU->CPU fallback is tagged exactly like a CPU run
    STATE.hw_swaps.append((list(vt), list(video) + (bt709_tag_args(enc) if bt709 else [])))
    return vt


def strip_movflags(args: List[str]) -> List[str]:
    return [a for i, a in enumerate(args) if not (a == "-movflags" or (i and args[i - 1] == "-movflags"))]


def restate_last_swap(before: List[str], after: List[str]) -> None:
    """A caller that edits an encoder line after encoder_args() returned it (export.py strips
    -movflags) restates the recorded swap, so run()'s GPU->CPU fallback still finds the slice."""
    if STATE.hw_swaps and STATE.hw_swaps[-1][0] == before:
        STATE.hw_swaps[-1] = (list(after), strip_movflags(STATE.hw_swaps[-1][1]))


def hdr_tag_args(meta: Optional[Dict[str, Any]]) -> List[str]:
    """The colour tags a 10-bit line that keeps a BT.2020 / HDR source writes as output options: the
    matrix it converted with (hdr_line_matrix), and the source's primaries and transfer."""
    v = (meta or {}).get("video") or {}
    return ["-colorspace", hdr_line_matrix(v), "-color_primaries", v.get("color_primaries") or "bt2020", "-color_trc", source_transfer(v)]


def encoder_args(codec: str, crf: int, preset: str, meta: Optional[Dict[str, Any]] = None, keep_bt709: bool = True) -> List[str]:
    """encoder options for `codec` (_cpu_encoder_args), on VideoToolbox when --hw asks and it can."""
    return _maybe_hw(codec, crf, meta, keep_bt709, _cpu_encoder_args(codec, crf, preset, meta, keep_bt709))


def _cpu_encoder_args(codec: str, crf: int, preset: str, meta: Optional[Dict[str, Any]] = None, keep_bt709: bool = True) -> List[str]:
    """The one place that turns (--codec, --quality, --preset, source) into encoder options.

    h264 -> x264 8-bit BT.709 (refuses HDR: 8-bit H.264 cannot carry it); hevc -> x265, Main10
    with the source's tags for HDR, 8-bit BT.709 otherwise; av1 -> SVT-AV1 (libaom fallback),
    10-bit for HDR; prores -> ProRes 422 HQ, source tags kept. 1.8: chosen by --codec; without
    it video_args() does what it always did (x264 for SDR, x265 Main10 for HDR).
    """
    v = (meta or {}).get("video") or {}
    hdr = bool(v.get("bt2020_or_hdr"))
    cs = hdr_line_matrix(v)
    prim = v.get("color_primaries") or "bt2020"
    trc = source_transfer(v)
    hdr_tags = hdr_tag_args(meta)
    if codec == "h264":
        if hdr:
            die(f"--codec h264 cannot carry HDR ({v.get('hdr_format') or 'BT.2020'}): 8-bit H.264 is SDR only",
                hint="run color.py --to-sdr first, or use --codec hevc / av1 / prores, which keep the source's HDR")
        return _x264_raw(crf, preset, keep_bt709)
    if codec == "hevc":
        if hdr:
            x265 = f"log-level=error:colorprim={prim}:transfer={trc}:colormatrix={cs}:range=limited:hdr10-opt=1{hdr10_x265_params(v)}" if trc == "smpte2084" else f"log-level=error:colorprim={prim}:transfer={trc}:colormatrix={cs}"
            return ["-c:v", "libx265", "-preset", preset, "-crf", str(_clamped_crf("libx265", crf + 2, 51, crf)), "-pix_fmt", "yuv420p10le", "-tag:v", "hvc1",
                    "-x265-params", x265] + hdr_tags + ["-movflags", "+faststart"]
        params, extra = _sdr_bt709("libx265") if keep_bt709 else ("", [])
        return ["-c:v", "libx265", "-preset", preset, "-crf", str(crf), "-pix_fmt", "yuv420p", "-tag:v", "hvc1",
                "-x265-params", "log-level=error" + (":" + params if params else "")] + extra + ["-movflags", "+faststart"]
    if codec == "av1":
        pix = "yuv420p10le" if hdr else "yuv420p"
        if "libsvtav1" in ffmpeg_encoders():
            args = ["-c:v", "libsvtav1", "-preset", str(SVT_PRESET.get(preset, 6)), "-crf", str(_clamped_crf("libsvtav1", crf, 63, crf)), "-pix_fmt", pix]
            if hdr:
                svt = hdr10_svtav1_params(v)
                args += (["-svtav1-params", svt] if svt else []) + hdr_tags
            elif keep_bt709:
                params, extra = _sdr_bt709("libsvtav1")
                args += (["-svtav1-params", params] if params else []) + extra
        elif "libaom-av1" in ffmpeg_encoders():
            # recorded: libaom is the slower AV1 encoder with its own CRF scale and speed setting,
            # so the same --quality does not give the file SVT-AV1 would have
            record_fallback("--codec av1: this ffmpeg build has no libsvtav1 (SVT-AV1), so libaom-av1 encodes instead "
                            "(slower; -cpu-used 6, its own CRF scale)", "av1_encoder_libaom", wanted="libsvtav1", used="libaom-av1")
            args = ["-c:v", "libaom-av1", "-crf", str(_clamped_crf("libaom-av1", crf, 63, crf)), "-b:v", "0", "-cpu-used", "6", "-row-mt", "1", "-pix_fmt", pix]
            args += hdr_tags if hdr else (_sdr_bt709("libaom-av1")[1] if keep_bt709 else [])
        else:
            _refuse_missing_encoder("av1", ["libsvtav1", "libaom-av1"], "an AV1 encoder (libsvtav1 or libaom-av1)",
                                    "install an ffmpeg built with SVT-AV1 (most distribution builds are), or use --codec hevc")
        return args + ["-movflags", "+faststart"]
    if codec == "prores":
        if "prores_ks" not in ffmpeg_encoders():
            _refuse_missing_encoder("prores", ["prores_ks"], "the prores_ks encoder", None)
        return ["-c:v", "prores_ks", "-profile:v", "3", "-vendor", "apl0", "-pix_fmt", "yuv422p10le"] + (hdr_tags if hdr else [])
    die(f"unknown --codec {codec!r} (one of {', '.join(CODECS)})")
    return []


def hdr10_x265_params(v: Dict[str, Any]) -> str:
    """The source's HDR10 static metadata as x265 options (":master-display=...:max-cll=..."), or "".
    FFmpeg before 7.0 does not pass the decoded frames' mastering-display / content-light side data
    to libx265, so without these a 6.1 re-encode wrote PQ video with neither (#401). Given on 7+ too,
    where they restate what FFmpeg would pass. x265 units: chromaticity 0.00002, luminance 0.0001 cd/m2."""
    md, cl = _hdr10_parts(v)
    out = ""
    if md:
        c = lambda k: round(md[k] * 50000)
        out += (f":master-display=G({c('green_x')},{c('green_y')})B({c('blue_x')},{c('blue_y')})R({c('red_x')},{c('red_y')})"
                f"WP({c('white_point_x')},{c('white_point_y')})L({round(md['max_luminance'] * 10000)},{round(md['min_luminance'] * 10000)})")
    if cl:
        out += f":max-cll={cl['max_content']},{cl['max_average']}"
    return out


def hdr10_svtav1_params(v: Dict[str, Any]) -> str:
    """The same for SVT-AV1 (-svtav1-params), which takes chromaticities and cd/m2 as decimals."""
    md, cl = _hdr10_parts(v)
    parts = []
    if md:
        f = lambda k: f"{md[k]:.5f}".rstrip("0").rstrip(".")
        parts.append(f"mastering-display=G({f('green_x')},{f('green_y')})B({f('blue_x')},{f('blue_y')})R({f('red_x')},{f('red_y')})"
                     f"WP({f('white_point_x')},{f('white_point_y')})L({f('max_luminance')},{f('min_luminance')})")
    if cl:
        parts.append(f"content-light={cl['max_content']},{cl['max_average']}")
    return ":".join(parts)


def _hdr10_parts(v: Dict[str, Any]) -> "Tuple[Optional[Dict[str, float]], Optional[Dict[str, int]]]":
    st = v.get("hdr10_static") or {}
    if v.get("color_transfer") != "smpte2084":
        return None, None
    return st.get("mastering_display"), st.get("content_light")


def _clamped_crf(encoder: str, value: int, top: int, requested: int) -> int:
    """`value` capped at the encoder's maximum CRF, the cap recorded (`crf_clamped`) when it
    bites: the HEVC HDR line asks x265 for CRF+2, so --quality 50 or 51 there is encoded at 51."""
    if value <= top:
        return value
    warn(f"{encoder}: CRF {value} (from {requested}) is above the encoder's maximum {top}; encoded at CRF {top}",
         "crf_clamped", encoder=encoder, requested=requested, asked=value, used=top)
    return top


def _refuse_missing_encoder(codec: str, encoders: List[str], what: str, hint: Optional[str]) -> None:
    """--codec av1/prores with no encoder for it -- or with an encoder list that could not be read,
    which proves nothing about the build and is refused under its own reason rather than as a
    missing encoder (ffmpeg_list_error)."""
    unread = ffmpeg_list_error("encoders")
    if unread:
        refuse("ffmpeg", "encoder_list_unreadable",
               f"--codec {codec} needs {what}, and whether this ffmpeg build has one is unknown: its encoder list "
               f"could not be read ({unread})",
               hint="check that ffmpeg runs (python3 scripts/_contract.py doctor), then retry",
               codec=codec, encoders=encoders, error=unread)
    refuse("missing_tool", "encoder_missing", f"--codec {codec} needs {what} and this ffmpeg build has "
           + ("neither" if len(encoders) > 1 else "none"), hint=hint, codec=codec, encoders=encoders)


def _x264_raw(crf: int, preset: str, keep_bt709: bool = True) -> List[str]:
    args = ["-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-pix_fmt", "yuv420p", "-movflags", "+faststart"]
    if keep_bt709:
        args += bt709_tag_args("libx264")
    return args


def keeps_source_tags() -> bool:
    """True when the line being written is an editing master that keeps the source's colour tags
    and converts no matrix: --codec prores, or an alpha line (--keep-alpha / --transparent,
    _common.alpha). The BT.709 conversions and labels below are for lines tagged BT.709."""
    return STATE.codec == "prores" or STATE.alpha_line is not None


def x264_args(crf: int = 18, preset: str = "medium", keep_bt709: bool = True,
              source: Optional[Dict[str, Any]] = None) -> List[str]:
    """SDR H.264 encoder args -- or, when --codec named another encoder, that encoder's SDR args
    (color.py's --to-sdr path builds its own H.264 line; the flag still has to reach it).

    `source`: the probe of the file being re-encoded, when the pixels reaching the encoder are
    still that file's. A BT.709-tagged line then carries the conversion of a non-BT.709 matrix
    (bt709_matrix_args); a caller whose graph already outputs BT.709 (--to-sdr) leaves it out."""
    if STATE.codec and STATE.codec != "h264":
        args = encoder_args(STATE.codec, crf, preset, None, keep_bt709)
    else:
        args = _maybe_hw("h264", crf, None, keep_bt709, _x264_raw(crf, preset, keep_bt709))
    return args + (bt709_matrix_args(source) if keep_bt709 and not keeps_source_tags() else [])


def video_args(meta: Optional[Dict[str, Any]], crf: int = 18, preset: str = "medium", convert_matrix: bool = True,
               source: Optional[Dict[str, Any]] = None) -> List[str]:
    """Encoder args that preserve what the source is.

    SDR sources -> H.264 8-bit tagged BT.709 (x264_args). HDR sources (HDR10/PQ, HLG,
    Dolby Vision base layer, BT.2020) -> HEVC Main10 with the source's own colour tags,
    so cutting/captioning/fitting an iPhone HDR clip stays HDR instead of becoming a
    washed-out file mislabelled as BT.709. Use color.py --to-sdr when SDR is wanted.

    An SDR source tagged with a BT.601 (or another non-BT.709) matrix is converted to BT.709
    before it is tagged so: the line ends with the `-vf` of bt709_matrix_args(), which run()
    folds into the tool's own graph (color.fold_bt709_matrix). `convert_matrix=False` is for a
    tool that mixes several sources and converts each one in its own graph (join, multicam,
    broll, overlay --video). --codec prores keeps the source's tags, so it converts nothing.
    An RGB source (a PNG, an image sequence, a qtrle clip) is converted the same way.

    `source`: the probe of the picture the encoder gets when the line is chosen without it
    (insert.py and sequence.py make a still or a PNG sequence into video on the SDR line,
    video_args(None)); its RGB or BT.601 pixels are converted to the BT.709 that line is tagged with.
    """
    v = (meta or {}).get("video") or {}
    fix = bt709_matrix_args(meta if source is None else source) if convert_matrix and not keeps_source_tags() else []
    if convert_matrix and source is None and STATE.alpha_line is None:
        # the BT.2020 / HDR line of an RGB source (--codec prores included: that line tags it too)
        fix = hdr_rgb_matrix_args(meta) or ([] if v.get("bt2020_or_hdr") else fix)
    if STATE.codec:
        return encoder_args(STATE.codec, crf, preset, meta) + fix
    if not v.get("bt2020_or_hdr"):
        return x264_args(crf, preset) + fix
    return _maybe_hw("hevc", crf, meta, True, _x265_hdr_default(v, crf, preset)) + fix


def line_matrix_filter(meta: Optional[Dict[str, Any]]) -> Optional[str]:
    """The conversion video_args(meta)'s line ends with for this source, as a filter, or None: for
    a tool that needs it inside a graph of its own before run() folds it in (stabilize.py's pass
    1, fit.py's picture measurement). bt709_matrix_filter() on a line tagged BT.709,
    hdr_rgb_matrix_filter() on a BT.2020 / HDR line; nothing on an alpha line, and nothing for an
    SDR source on --codec prores."""
    if STATE.alpha_line is not None:
        return None
    hdr = ((meta or {}).get("video") or {}).get("bt2020_or_hdr")
    return hdr_rgb_matrix_filter(meta) or (None if keeps_source_tags() or hdr else bt709_matrix_filter(meta))


def matrix_chain(meta: Optional[Dict[str, Any]], line_meta: Optional[Dict[str, Any]]) -> str:
    """For a tool that mixes several sources in one graph and encodes it through
    video_args(line_meta, convert_matrix=False): the conversion one source's own chain starts
    with ("<filter>," -- bt709_matrix_filter), or "" when that source needs none or the line does
    not tag BT.709 (an HDR/BT.2020 line keeps its tags, --codec prores keeps the source's). On a
    BT.2020 / HDR line an RGB source that probes BT.2020 or HDR itself is made YUV with the matrix
    that line tags (hdr_rgb_matrix_filter, #544)."""
    if ((line_meta or {}).get("video") or {}).get("bt2020_or_hdr") and STATE.alpha_line is None:
        f = hdr_rgb_matrix_filter(meta, line_meta)
        return f + "," if f else ""
    if keeps_source_tags() or ((line_meta or {}).get("video") or {}).get("bt2020_or_hdr"):
        return ""
    f = bt709_line_filter(meta)
    return f + "," if f else ""


def label_chain(meta: Optional[Dict[str, Any]], line_meta: Optional[Dict[str, Any]]) -> str:
    """For a picture that meets a converted one in a mixing filter (a still over the video, a grid
    cell beside a converted cell), encoded through video_args(line_meta): the BT.709 label an
    untagged one's chain starts with ("<setparams>," -- bt709_label_filter), or "" (a tagged, RGB or
    HDR picture, or a line that does not tag BT.709)."""
    if keeps_source_tags() or ((line_meta or {}).get("video") or {}).get("bt2020_or_hdr"):
        return ""
    f = bt709_label_filter(meta)
    return f + "," if f else ""


def range_chain(meta: Optional[Dict[str, Any]], line_meta: Optional[Dict[str, Any]]) -> str:
    """For a picture that a mixing filter (concat, xfade, xstack, overlay) puts beside or under
    another, encoded through video_args(line_meta): the conversion to limited range its chain
    takes after its matrix_chain()/label_chain() ("<filter>," -- limited_range_filter), or "" (a
    limited, RGB or HDR picture, or a line that does not tag BT.709). Every SDR picture such a
    tool mixes is then limited range, whatever each one was: the filters mix samples, not colours."""
    if keeps_source_tags() or ((line_meta or {}).get("video") or {}).get("bt2020_or_hdr"):
        return ""
    f = limited_range_filter(meta)
    return f + "," if f else ""


def layer_base_chain(meta: Optional[Dict[str, Any]]) -> str:
    """The chain in front of the picture `meta` probes where converted RGB layers (rgb_chain_to_bt709:
    a still, an emoji PNG, a box of chroma) are overlaid on it: an untagged picture's BT.709 label
    (label_chain) and, for a full-range one, its conversion to the limited range the layers are
    made in (range_chain). "" when the line converts no layer (HDR, prores)."""
    if not rgb_chain_to_bt709(meta):
        return ""
    return label_chain(meta, meta) + range_chain(meta, meta)


def rgb_chain_to_bt709(line_meta: Optional[Dict[str, Any]], pix_fmt: str = "yuva420p") -> str:
    """For a picture the tool's own graph has made RGB(A) -- a still's `format=rgba` chain
    (overlay.py --image, an emoji PNG) or an RGBA composite (waveform.py's --image plate) -- that
    is encoded through video_args(line_meta): "," + the conversion to BT.709 YUV to end that chain
    with (rgb_to_bt709_filter), or "" when the line does not tag BT.709 (the lines matrix_chain()
    leaves alone). Without it the graph's own RGB-to-YUV step used FFmpeg's BT.601 default."""
    v = (line_meta or {}).get("video") or {}
    if (STATE.alpha_line is not None and (v.get("color_space") == "bt709" or rgb_to_bt709_line(line_meta))
            and not v.get("bt2020_or_hdr")):
        # an alpha line keeps the source's tags: on a BT.709-tagged picture an RGB layer is made
        # BT.709 too (FFmpeg 6.1's own conversion is BT.601), in 4:4:4 with its alpha plane. An
        # RGB source on a YUV line is a BT.709 picture as well (alpha.rgb_to_bt709_line, #496)
        return "," + rgb_to_bt709_filter("yuva444p")
    if keeps_source_tags() or v.get("bt2020_or_hdr"):
        return ""
    return "," + rgb_to_bt709_filter(pix_fmt)


def overlay_format(meta: Optional[Dict[str, Any]]) -> str:
    """":format=..." for an `overlay` whose main picture is the one `meta` probes, or "".

    overlay's default format is `yuv420`, which is 8-bit, and `format=auto` picks an 8-bit one as
    soon as the layer is 8-bit, so through 3.6.0 a cutaway, a redaction, a graphics layer or a PiP
    over a 10-bit HDR or ProRes source took the whole picture to 8 bits (and `overlay --image`'s
    RGBA logo took it through 8-bit RGB) before the 10-bit encoder. On a line that keeps more than
    8 bits (HDR/BT.2020, --codec prores) and a main picture deeper than 8 bits the overlay runs at
    10 bits in the main's own chroma subsampling, and an 8-bit layer is widened to meet it (bit
    depth only, no matrix). An alpha line keeps the format its tool chose."""
    v = (meta or {}).get("video") or {}
    if STATE.alpha_line is not None or (v.get("bit_depth") or 8) <= 8:
        return ""
    if not (v.get("bt2020_or_hdr") or keeps_source_tags()):
        return ""
    pix = v.get("pix_fmt") or ""
    sub = "444" if "444" in pix else "422" if "422" in pix else "420"
    return f":format=yuv{sub}p10"


def draws_chroma(colours: Sequence[Any], line_meta: Optional[Dict[str, Any]]) -> bool:
    """True when one of `colours` has chroma (is_neutral_color) and the line video_args(line_meta)
    tags the output BT.709 -- when a drawn colour needs drawn_chain() at all."""
    return (not all(is_neutral_color(c) for c in colours if c is not None) and not keeps_source_tags()
            and not ((line_meta or {}).get("video") or {}).get("bt2020_or_hdr"))


def drawn_chain(colour_chain: str, meta: Optional[Dict[str, Any]], colours: Sequence[Any], neutral_chain: str = "null",
                line_meta: Any = "same", tag: str = "d", labelled: bool = False) -> str:
    """`colour_chain` -- filters that draw a colour into the picture `meta` probes (drawtext's
    font/box/border colours, pad/tpad's fill, rotate's fillcolor, libass) -- so that a colour of
    `colours` lands in the BT.709 the line video_args(line_meta) tags the output with (line_meta
    defaults to meta).

    FFmpeg's drawing filters turn an RGB colour into YUV with a matrix of their own (ff_draw):
    BT.601 always up to 7.0, the link's colourspace from 7.1 on, "unknown" read as BT.601. Through
    2.10.2 a drawn colour was BT.601 under a BT.709 tag on every build (pure red decoded as
    (255,24,0)), and on 5.1/6.1 for a BT.709-tagged source too. From 7.1 an untagged picture gets
    its BT.709 label (label_chain(): tags only) and the filters follow it; before 7.1 the drawing
    runs in RGB (rgb_island(), `neutral_chain` being the same filters with a black fill, or null).

    Unchanged: a chain whose colours are all greys (the same YUV under every matrix: the default
    black pads and white text), a line that does not tag BT.709 (HDR, prores). `labelled`: the
    caller's graph already labels this picture (label_chain()) earlier in the same chain.

    Before 7.1 `ff_draw` also takes the range from the pixel format alone: full for `yuvj`, limited
    for every other, so on a full-range picture in a plain format (VP9/AV1 full range, 10-bit full
    range) even black and white were drawn limited (pad black read 101010, #410), and 6.1's scale
    has often made such a picture limited before the drawing anyway. There the picture is first
    taken to limited range (range_chain(), which reads the range from the frames), and the
    drawing, the colours and rgb_island() all work in limited range. 7.1+ draws in the link's
    range and is left as it is."""
    line = meta if line_meta == "same" else line_meta
    pre = ""
    if ffmpeg_version() < (7, 1) and not str(((meta or {}).get("video") or {}).get("pix_fmt") or "").startswith("yuvj"):
        pre = range_chain(meta, line)
    if not draws_chroma(colours, line):
        return pre + colour_chain
    if ffmpeg_version() >= (7, 1):
        return ("" if labelled else label_chain(meta, line)) + colour_chain
    pix_fmt, full = drawn_stream_format(as_limited(meta) if pre else meta)
    return pre + rgb_island(colour_chain, neutral_chain, pix_fmt, full, tag)


def source_codec_video_args(meta: Optional[Dict[str, Any]], crf: int = 18, preset: str = "medium",
                            keep_hevc: bool = False) -> List[str]:
    """video_args(), except that with `keep_hevc` (cut.py --keep-hevc) an SDR HEVC source re-encodes
    to HEVC (8-bit, BT.709-tagged, on VideoToolbox when --hw asks) instead of H.264: a cut is a trim,
    so a re-encoded segment can come out in the codec the source (and any copied segment beside it)
    is in. Opt-in within 2.x, where an SDR re-encode stays x264 unless asked. An HDR or BT.2020
    source always takes video_args()'s Main10 line, and --codec always wins."""
    v = (meta or {}).get("video") or {}
    if keep_hevc and not STATE.codec and v.get("codec") == "hevc" and not v.get("bt2020_or_hdr"):
        return encoder_args("hevc", crf, preset, meta) + bt709_matrix_args(meta)
    return video_args(meta, crf, preset)


def _x265_hdr_default(v: Dict[str, Any], crf: int, preset: str) -> List[str]:
    cs = hdr_line_matrix(v)
    prim = v.get("color_primaries") or "bt2020"
    trc = source_transfer(v)
    x265 = f"log-level=error:colorprim={prim}:transfer={trc}:colormatrix={cs}:range=limited:hdr10-opt=1{hdr10_x265_params(v)}" if trc == "smpte2084" else f"log-level=error:colorprim={prim}:transfer={trc}:colormatrix={cs}"
    return ["-c:v", "libx265", "-preset", preset, "-crf", str(min(51, crf + 2)), "-pix_fmt", "yuv420p10le", "-tag:v", "hvc1",
            "-x265-params", x265, "-colorspace", cs, "-color_primaries", prim, "-color_trc", trc, "-movflags", "+faststart"]


def aac_args(bitrate: str = "192k") -> List[str]:
    return ["-c:a", "aac", "-b:a", bitrate]


AUDIO_CODECS = {
    ".wav": ["-c:a", "pcm_s16le"],
    ".flac": ["-c:a", "flac"],
    ".mp3": ["-c:a", "libmp3lame", "-q:a", "0"],
    ".m4a": ["-c:a", "aac", "-b:a", "256k"],
    ".aac": ["-c:a", "aac", "-b:a", "256k"],
    ".ogg": ["-c:a", "libvorbis", "-q:a", "6"],
    ".opus": ["-c:a", "libopus", "-b:a", "128k"],
    # 16-bit PCM as for .wav, big-endian: the AIFF and CAF muxers' own default codec (#517)
    ".aif": ["-c:a", "pcm_s16be"],
    ".aiff": ["-c:a", "pcm_s16be"],
    ".caf": ["-c:a", "pcm_s16be"],
    ".mka": ["-c:a", "flac"],
}


LOSSLESS_AUDIO_EXT = {".wav", ".flac", ".aif", ".aiff", ".caf", ".mka"}  # the AUDIO_CODECS whose codec takes no bitrate

# Every audio-only extension this skill reads (AUDIO_MEDIA_EXT) that has no codec above: a run
# that would encode into an output named so is refused before ffmpeg runs, and only a stream copy
# of WMA sound is written (runner.refuse_unwritten_output(), #517). That is .wma: FFmpeg's ASF
# muxer took the tools' H.264 and AAC and wrote them under the name, verified.
UNWRITTEN_AUDIO_EXT = frozenset(AUDIO_MEDIA_EXT - set(AUDIO_CODECS))


def audio_codec_for(output_path: str, bitrate: Optional[str] = None) -> List[str]:
    """Pick an audio codec that the output container can actually hold.

    `bitrate` is one the caller asked for: it replaces the rate or quality an audio extension
    names (`-q:a 0` for .mp3, 256k for .m4a), which through 3.8.8 it never reached (A143), and is
    the AAC rate of any other container (192k when it is None). A lossless extension takes none;
    the caller refuses a bitrate for it."""
    ext = os.path.splitext(output_path)[1].lower()
    if ext not in AUDIO_CODECS:
        return ["-c:a", "aac", "-b:a", bitrate or "192k"]
    args = list(AUDIO_CODECS[ext])
    if bitrate is None or ext in LOSSLESS_AUDIO_EXT:
        return args
    for flag in ("-b:a", "-q:a"):
        if flag in args:
            i = args.index(flag)
            del args[i:i + 2]
    return args + ["-b:a", bitrate]


def is_audio_output(output_path: str) -> bool:
    """True when the output extension is an audio-only container this skill writes (AUDIO_CODECS:
    .wav, .flac, .mp3, .m4a, .aac, .ogg, .opus, .aif, .aiff, .caf, .mka).

    Scripts use this to drop the picture (-vn) and to pick the output codec from the extension.
    """
    return os.path.splitext(output_path)[1].lower() in AUDIO_CODECS


def db_to_linear(db: float) -> float:
    return 10 ** (db / 20.0)


BRAND_DEFAULTS: Dict[str, Any] = {
    "font": "DejaVu Sans",
    "font_file": None,
    "colors": {"primary": "FFD200", "text": "FFFFFF", "outline": "000000", "background": "101418", "accent": "1E6F8E"},
    "logo": None,
    "logo_position": "top-right",
    "logo_scale": 160,
    "logo_opacity": 0.9,
    "safe_margin": 48,
    "caption": {"size": 26, "position": "bottom", "animate": "pop", "karaoke": False, "bold": True, "outline": 2},
    # 1.12: one place for the caption look every project shares. `styles.caption` is the documented
    # spelling (`{font, size, colour, box, position}`, British or American "colour"); the older
    # top-level `caption` block still works and `styles.caption` wins where both name the same key.
    "styles": {},
    "lang": None,
    "loudness": {"lufs": -14, "tp": -1},
}


# Every key a tool reads from a brand file, per block (#510). `styles.caption` is merged over the
# top-level `caption` block (brand_caption_style()), so the two take the same keys. `colors.accent`
# is a palette entry BRAND_DEFAULTS and examples/brand.json carry; `loudness` is read by no tool
# (A107) and is kept out of the refusal, since the example shipped it until 3.8.8: it gets a note.
BRAND_KEYS: Dict[str, frozenset] = {
    "": frozenset({"font", "font_file", "colors", "logo", "logo_position", "logo_scale", "logo_opacity",
                   "safe_margin", "caption", "styles", "lang", "emoji_assets", "loudness"}),
    "colors": frozenset({"primary", "text", "outline", "background", "accent", "upcoming"}),
    "caption": frozenset({"size", "position", "animate", "karaoke", "bold", "outline", "box", "color", "colour",
                          "font", "emoji_assets"}),
    "styles": frozenset({"caption"}),
}
BRAND_KEYS["styles.caption"] = BRAND_KEYS["caption"]


def check_brand_keys(data: Dict[str, Any], path: str) -> None:
    """Refuse a brand file key no tool reads, as render.py refuses a project's (check_keys()): a
    misspelt `"safe_margn"` or `"colours"` was dropped without a word and the defaults drawn."""
    import difflib
    import json
    blocks = [("", data)]
    for name in ("colors", "caption", "styles"):
        if isinstance(data.get(name), dict):
            blocks.append((name, data[name]))
    if isinstance(data.get("styles"), dict) and isinstance(data["styles"].get("caption"), dict):
        blocks.append(("styles.caption", data["styles"]["caption"]))
    for block, obj in blocks:
        for key in obj:
            if key in BRAND_KEYS[block]:
                continue
            where = f"{block}.{key}" if block else str(key)
            near = difflib.get_close_matches(str(key), sorted(BRAND_KEYS[block]), n=1)
            # quoted as JSON: the key is the caller's text, and a quote or a line break in it stays one line
            die(f"brand file {path}: unknown key {json.dumps(where)}" + (f' (did you mean "{near[0]}"?)' if near else ""),
                kind="input", hint=f"the keys read{' in ' + block if block else ''}: " + ", ".join(sorted(BRAND_KEYS[block])))
    if "loudness" in data:
        note(f'brand file {path}: "loudness" is read by no tool and was ignored (a target is loudness.py -I, '
             'export.py\'s preset, or a render project\'s "loudness")')


BRAND_FILE_KEYS = ("logo", "font_file")  # the brand keys that name a file a tool reads


def brand_asset_files(path: str) -> List[Tuple[str, str]]:
    """(key, path) of each file a brand file names (logo, font_file), resolved as load_brand()
    resolves them: against the brand file's own directory. What a cache key must hash beside the
    brand file's own bytes, since a logo or a font replaced under its name changes the output
    (render.py --cache; batch.py's side inputs, #510 review). A brand file that cannot be read
    names nothing here; the tool refuses it when it runs."""
    try:
        data = read_json(path)
    except (OSError, ValueError):
        return []
    if not isinstance(data, dict):
        return []
    base = Path(path).resolve().parent
    out: List[Tuple[str, str]] = []
    for key in BRAND_FILE_KEYS:
        value = data.get(key)
        if isinstance(value, str) and value:
            out.append((key, value if os.path.isabs(value) else str(base / value)))
    return out


def load_brand(path: Optional[str]) -> Dict[str, Any]:
    """Load brand.json (fonts, colours, logo, safe margins, caption defaults); missing keys fall back to defaults."""
    import copy
    brand = copy.deepcopy(BRAND_DEFAULTS)
    brand["_stated"] = {}
    if not path:
        return brand
    if not os.path.exists(path):
        die(f"brand file {absent_word(path)}: {path}", kind="input")
    try:
        data = read_json(path)
    except OSError as exc:
        die(f"brand file {path} cannot be read: {exc.strerror or exc}", kind="input")
    except ValueError as exc:  # malformed, not UTF-8, or nested too deep (read_json)
        die(f"brand file is not valid JSON: {exc}", kind="input")
    if not isinstance(data, dict):
        die(f"brand file {path} must be a JSON object {{...}}, got {type(data).__name__}", kind="input")
    # the shapes the readers below and brand_caption_style() walk: a block that is not an object,
    # and a path that is not a string, were a traceback there
    for key, value in (*data.items(), ("styles.caption", (data.get("styles") or {}).get("caption")
                                       if isinstance(data.get("styles"), dict) else None)):
        if value is None:
            continue
        if (isinstance(BRAND_DEFAULTS.get(key), dict) or key == "styles.caption") and not isinstance(value, dict):
            die(f'brand file {path}: "{key}" must be an object {{...}}, got {type(value).__name__}', kind="input")
        if key in ("logo", "font_file", "font") and not isinstance(value, str):
            die(f'brand file {path}: "{key}" must be a string, got {type(value).__name__}', kind="input")
    check_brand_keys(data, path)
    base = Path(path).resolve().parent
    for k, v in data.items():
        if v is None and isinstance(brand.get(k), dict):
            continue  # a null block keeps its defaults: readers walk it as an object (#483 review)
        if isinstance(v, dict) and isinstance(brand.get(k), dict):
            brand[k].update(v)
        else:
            brand[k] = v
    for key in ("logo", "font_file"):
        if brand.get(key) and not os.path.isabs(brand[key]):
            brand[key] = str(base / brand[key])
        # a file the run reads: a --plan binds it and is never written over it (review of #534's
        # sweep: caption.py hands libass the font's folder, so its plan named neither)
        if brand.get(key) and os.path.isfile(brand[key]) and brand[key] not in STATE.plan_inputs:
            STATE.plan_inputs.append(brand[key])
    brand["_path"] = str(path)
    # What the FILE said, separate from BRAND_DEFAULTS' filler: a brand.json that never mentions
    # a font must not read as "the caller chose a font" (which would switch font-by-script off).
    brand["_stated"] = data
    return brand


# Every key of a render.py project that names a file. render.py reads each one relative to the
# project file (its rel()); a copy of the project written anywhere else -- batch.py's per-item
# project in its work directory, multicam.py --write-project -- has to carry them absolute, or
# render looks for "bed.wav" beside the copy. A path is (section, key): section None is the
# project's top level, "x[]" each entry of the list x. tests/test_contract.py checks that every
# rel() in render.py reads one of these.
PROJECT_PATH_KEYS = (
    (None, "output"), (None, "brand"), (None, "chapters"),
    ("clips[]", "src"), ("clips[].snap", "source"), ("snap", "source"),
    ("audio", "music"), ("audio", "replace"), ("audio", "effects"),
    ("captions", "text"), ("captions", "srt"), ("captions", "ass"),
    ("overlays[]", "image"), ("overlays[]", "video"), ("overlays[]", "font_file"),
    ("audiogram", "image"),
)


def rebase_project_paths(proj: Dict[str, Any], base: "os.PathLike[str] | str") -> Dict[str, Any]:
    """A copy of a render.py project whose relative file paths (PROJECT_PATH_KEYS) are joined onto
    `base`, the directory they were written relative to; absolute paths, URLs, non-strings, inline
    chapter lists and keys the project does not have are left as they are."""
    import copy
    out = copy.deepcopy(proj)
    base = Path(base)

    def fix(obj: Any, key: str) -> None:
        value = obj.get(key) if isinstance(obj, dict) else None
        # a URL is left for the tool to refuse by what it is (waveform.py: no network access)
        if isinstance(value, str) and value and not os.path.isabs(value) and "://" not in value:
            obj[key] = str(base / value)

    def nodes(section: "Optional[str]") -> List[Any]:
        found: List[Any] = [out]
        for part in (section.split(".") if section else []):
            name, many = (part[:-2], True) if part.endswith("[]") else (part, False)
            nxt: List[Any] = []
            for node in found:
                value = node.get(name) if isinstance(node, dict) else None
                nxt.extend(value if many and isinstance(value, list) else [] if many else [value])
            found = nxt
        return found
    for section, key in PROJECT_PATH_KEYS:
        for node in nodes(section):
            fix(node, key)
    return out


def brand_states_font(brand: Dict[str, Any]) -> bool:
    """Did the brand FILE actually name a font (top-level `font`, `caption.font` or
    `styles.caption.font`)? BRAND_DEFAULTS always supplies one, so the merged document can never
    answer this -- and treating the default filler as the caller's choice switched font-by-script
    off for every branded job (review 10)."""
    stated = brand.get("_stated") or {}
    if stated.get("font"):
        return True
    for block in (stated.get("caption"), (stated.get("styles") or {}).get("caption")):
        if isinstance(block, dict) and block.get("font"):
            return True
    return False


def brand_caption_style(brand: Dict[str, Any]) -> Dict[str, Any]:
    """The effective caption style of a brand file: the top-level `caption` block updated with
    `styles.caption`, with `colour` normalised to `color`. Explicit flags still beat both."""
    style: Dict[str, Any] = dict(brand.get("caption") or {})
    extra = (brand.get("styles") or {}).get("caption") or {}
    style.update(extra)
    if "colour" in style and "color" not in style:
        style["color"] = style.pop("colour")
    style.pop("colour", None)
    return style


# ------------------------------------------------------------------- chapter proposal (1.16)

def fmt_chapter_time(t: float) -> str:
    """The YouTube description convention: `00:00`, `03:12`, `1:02:03` past the hour, always
    rounded DOWN to the second so the timestamp never lands after the moment it names."""
    total = max(0, int(t))
    h, rem = divmod(total, 3600)
    m, sec = divmod(rem, 60)
    if h:
        return f"{h}:{m:02d}:{sec:02d}"
    return f"{m:02d}:{sec:02d}"


def _evidence_rank(ev: Dict[str, Any]) -> tuple:
    """How strong a candidate is, for the drop order: both detectors beat a silence, a silence
    beats a scene cut, and within a kind the longer pause / higher score wins."""
    kind = ev.get("kind")
    tier = {"start": 3, "silence+scene": 2, "silence": 1, "scene": 0}.get(kind, 0)
    within = float(ev.get("silence_length") or ev.get("score") or 0.0)
    return (tier, within)


def propose_chapters(duration: float, silences: "Sequence", scene_cuts: "Sequence", *,
                     min_chapter: float = 60.0, max_chapters: int = 0,
                     source: str = "both") -> "List[Dict[str, Any]]":
    """Chapter markers proposed from measured structure. Pure: the detectors' outputs go in,
    a list of `{"at", "title", "evidence"}` comes out, and nothing is decoded here.

    A chapter starts where speech RESUMES, so a silence contributes its `end`, not its midpoint.
    A scene cut within 1 s of such a point is the same event seen twice and is merged into one
    candidate with `kind: "silence+scene"`, which the `--max-chapters` cap never drops before a
    single-evidence one. Candidates closer than `min_chapter` to the one already kept are dropped,
    stronger evidence winning; so is anything inside `min_chapter` of the end of the file.

    Every title is `Chapter N`. The function never looks at, and never invents, content: naming a
    chapter needs knowing what is said in it, which is the calling agent's job, not this skill's.
    """
    duration = float(duration or 0.0)
    min_chapter = max(0.0, float(min_chapter))
    candidates: "List[Dict[str, Any]]" = []
    if source in ("silence", "both"):
        for span in silences or []:
            start, end = float(span[0]), span[1]
            if end is None or end == float("inf"):
                continue
            end = float(end)
            candidates.append({"at": end, "evidence": {
                "kind": "silence", "silence": [round(start, 3), round(end, 3)],
                "silence_length": round(end - start, 3)}})
    if source in ("scenes", "both"):
        for cut in scene_cuts or []:
            cut = float(cut)
            if cut <= 0.0:
                continue     # scenes.py always reports 0.0 as the first cut; that is the start
            candidates.append({"at": cut, "evidence": {"kind": "scene", "scene_at": round(cut, 3)}})

    # merge a scene cut that stands within 1 s of a silence end: one event, two witnesses
    candidates.sort(key=lambda c: c["at"])
    merged: "List[Dict[str, Any]]" = []
    for cand in candidates:
        prior = merged[-1] if merged else None
        if prior and abs(cand["at"] - prior["at"]) <= 1.0 and \
                {prior["evidence"]["kind"], cand["evidence"]["kind"]} == {"silence", "scene"}:
            ev = dict(prior["evidence"])
            ev.update(cand["evidence"])
            ev["kind"] = "silence+scene"
            silence_first = prior["evidence"]["kind"] == "silence"
            prior["at"] = prior["at"] if silence_first else cand["at"]
            prior["evidence"] = ev
            continue
        merged.append(dict(cand))

    kept: "List[Dict[str, Any]]" = [{"at": 0.0, "evidence": {"kind": "start"}}]
    for cand in merged:
        if duration and cand["at"] >= duration - min_chapter:
            continue
        last = kept[-1]
        if cand["at"] - last["at"] < min_chapter:
            # too close to the marker already kept: keep whichever the evidence supports better,
            # never replacing the 0.0 start
            if last["evidence"]["kind"] != "start" and \
                    _evidence_rank(cand["evidence"]) > _evidence_rank(last["evidence"]) and \
                    (len(kept) < 2 or cand["at"] - kept[-2]["at"] >= min_chapter):
                kept[-1] = dict(cand)
            continue
        kept.append(dict(cand))

    if max_chapters and len(kept) > max_chapters:
        # drop the weakest evidence first, never index 0, then put the survivors back in order
        order = sorted(range(1, len(kept)),
                       key=lambda i: (_evidence_rank(kept[i]["evidence"]), -kept[i]["at"]))
        drop = set(order[:len(kept) - max_chapters])
        kept = [c for i, c in enumerate(kept) if i not in drop]

    for n, chapter in enumerate(kept, start=1):
        chapter["at"] = round(chapter["at"], 3)
        chapter["title"] = f"Chapter {n}"
    return kept


def description_block(chapters: "Sequence") -> str:
    """The YouTube description form of a chapter list: `00:00 Chapter 1` per line."""
    return "\n".join(f"{fmt_chapter_time(c['at'])} {c['title']}" for c in chapters)


# ------------------------------------------------------------------ the beat grid (1.17)
#
# A beat grid is a measurement of the music's periodicity -- not a statement about where a cut
# belongs. Everything here is arithmetic on an RMS envelope somebody else decoded; nothing in this
# module decides to cut anything, and nothing invents a beat the audio does not support.

BEAT_ONSET_K = 1.5          # peak threshold: median + k * MAD over the local window
BEAT_WINDOW_S = 1.0         # +/- this many seconds is "local" for the threshold
BEAT_REFRACTORY_S = 0.06    # two onsets closer than this are one onset
BEAT_SUPPORT_DIVISOR = 4    # a grid point with no onset within interval/4 is "unsupported"
BEAT_ALIGN_DIVISOR = 8      # an onset within interval/8 of a grid point counts as aligned
BEAT_MIN_CONFIDENCE = 0.5   # the default below which a tool that CHANGES a file refuses to snap
BEAT_OCTAVE_MARGIN = 1.2    # a half/double-tempo grid must explain this much more onset strength
BEAT_Z_FLOOR = 2.0          # autocorrelation z-score at which periodicity starts counting
BEAT_Z_SPAN = 4.0           # ... and the span over which it reaches 1.0


def _onset_strength(envelope: "Sequence[float]") -> "List[float]":
    """Half-wave-rectified first difference of log(env), i.e. a compression-domain spectral-flux
    analogue. The log matters: the level-domain difference over-weights the loud sections, so a
    quiet verse contributes no onsets at all and the tempo is measured on the chorus alone."""
    import math as _math
    log_env = [_math.log(max(0.0, float(e)) + 1e-9) for e in envelope]
    return [0.0] + [max(0.0, log_env[i] - log_env[i - 1]) for i in range(1, len(log_env))]


def _pick_onsets(strength: "Sequence[float]", step_s: float) -> "List[int]":
    """Indices of local maxima above median + k*MAD over a +/-BEAT_WINDOW_S window, with a
    refractory gap. A median/MAD threshold rather than a mean/stdev one because a handful of very
    strong hits would drag a mean-based threshold above every other onset in the piece."""
    n = len(strength)
    if n < 3:
        return []
    half = max(1, int(round(BEAT_WINDOW_S / max(step_s, 1e-9))))
    refractory = max(1, int(round(BEAT_REFRACTORY_S / max(step_s, 1e-9))))
    picked: "List[int]" = []
    for i in range(1, n - 1):
        s = strength[i]
        if s <= 0 or s < strength[i - 1] or s < strength[i + 1]:
            continue
        window = sorted(strength[max(0, i - half):min(n, i + half + 1)])
        if not window:
            continue
        med = window[len(window) // 2]
        devs = sorted(abs(x - med) for x in window)
        mad = devs[len(devs) // 2]
        if s < med + BEAT_ONSET_K * mad or s <= med:
            continue
        if picked and i - picked[-1] < refractory:
            if s > strength[picked[-1]]:
                picked[-1] = i
            continue
        picked.append(i)
    return picked


def _autocorrelation_peak(strength: "Sequence[float]", step_s: float,
                          bpm_range: "Sequence[float]") -> "tuple":
    """(best lag in samples, peak, mean, standard deviation) of the onset signal's
    autocorrelation over the lags `bpm_range` allows, or (None, 0.0, 0.0, 0.0).

    The spread matters as much as the peak: every signal's autocorrelation has a maximum
    somewhere, so "the peak is above the mean" says nothing. How far above it stands relative to
    the spread of the other lags is what separates a pulse from noise.
    """
    n = len(strength)
    hi_bpm, lo_bpm = max(bpm_range), min(bpm_range)
    lag_min = max(1, int(round(60.0 / hi_bpm / max(step_s, 1e-9))))
    lag_max = int(round(60.0 / lo_bpm / max(step_s, 1e-9)))
    lag_max = min(lag_max, n - 1)
    if lag_max < lag_min:
        return (None, 0.0, 0.0, 0.0)
    mean = sum(strength) / n if n else 0.0
    centred = [s - mean for s in strength]
    best_lag, best = None, 0.0
    values = []
    for lag in range(lag_min, lag_max + 1):
        acc = sum(centred[i] * centred[i + lag] for i in range(n - lag))
        acc /= (n - lag)
        values.append(acc)
        if best_lag is None or acc > best:
            best_lag, best = lag, acc
    mean_acc = sum(values) / len(values) if values else 0.0
    var = sum((v - mean_acc) ** 2 for v in values) / len(values) if values else 0.0
    return (best_lag, best, mean_acc, math.sqrt(var))


def _grid_score(onset_times: "Sequence[float]", strength_at: "Dict[int, float]",
                interval: float, phase: float) -> float:
    """Total onset strength landing within interval/BEAT_ALIGN_DIVISOR of the grid."""
    if interval <= 0:
        return 0.0
    tol = interval / BEAT_ALIGN_DIVISOR
    total = 0.0
    for i, t in enumerate(onset_times):
        off = (t - phase) % interval
        if min(off, interval - off) <= tol:
            total += strength_at.get(i, 1.0)
    return total


BEAT_ZERO_TOL_S = 0.01      # a fitted grid point this little before 0 s is the beat at 0.0
BEAT_REFINE_TOL_NATS = 1.0  # onset refinement: the latest time within this of the best log ratio


def refine_onset_times(onset_times: "Sequence[float]", step_s: float, pcm: "Sequence[float]",
                       rate: int) -> "List[float]":
    """Each envelope-step onset time placed at the sample where the sound starts. Pure.

    An onset picked on the step_s envelope is only known to the step: it is the start of the block
    the level rose in, so a click is reported up to one step early (5 ms on average at 10 ms).
    Around each one, over [t - step, t + 2 step], every candidate time c is scored by
    log(energy of [c, c + step]) - log(energy of [c - step, c]) -- the rise from the step before c
    to the step after it, which is largest where the sound starts. Ahead of a hit out of digital
    silence that score is flat (the window before is silent wherever it ends), so the LATEST
    candidate within BEAT_REFINE_TOL_NATS of the best is taken: past the start, the window before
    fills with the hit's own attack and the score falls off at once. Candidates are 0.25 ms apart.
    A time the PCM does not cover is returned unchanged.
    """
    rate = int(rate)
    w = max(1, int(round(step_s * rate)))
    hop = max(1, int(round(rate * 0.00025)))
    n = len(pcm)
    out: "List[float]" = []
    for t in onset_times:
        centre = int(round(t * rate))
        lo, hi = centre - w, centre + 2 * w
        if lo - w < 0 or hi + w > n:
            out.append(t)
            continue
        base = lo - w
        prefix = [0.0]
        acc = 0.0
        for x in pcm[base:hi + w + 1]:
            acc += x * x
            prefix.append(acc)
        scored = []
        for c in range(lo, hi + 1, hop):
            k = c - base
            before = (prefix[k] - prefix[k - w]) / w
            after = (prefix[k + w] - prefix[k]) / w
            scored.append((math.log(after + 1e-12) - math.log(before + 1e-12), c))
        best = max(sc for sc, _ in scored)
        c_best = max(c for sc, c in scored if sc >= best - BEAT_REFINE_TOL_NATS)
        out.append(c_best / rate)
    return out


def _refine_grid(onset_times: "Sequence[float]", strengths: "Sequence[float]", interval: float,
                 phase: float, lo_bpm: float, hi_bpm: float) -> "tuple":
    """(interval, phase) refitted by weighted least squares to the onsets that land on the grid.

    Each grid point k is paired with the STRONGEST onset within interval/BEAT_ALIGN_DIVISOR of it
    (one per point: the weak onsets noise and a hit's own decay leave around a beat must not pull
    it), and onset_time = phase + k * interval is solved for both unknowns with each pair weighted
    by its onset strength squared; the pairing is then redone against the refitted grid, until it
    stops moving (three passes at most). This only sharpens the grid the autocorrelation chose --
    the tempo cannot leave `bpm_range` (a fit beyond a bound is held on it), an octave cannot flip (a refit that moves the interval by
    more than interval/BEAT_ALIGN_DIVISOR is discarded), and fewer than four paired grid points
    keep the original: the fit needs evidence, and an onset-free stretch gives it none.
    Returns phase in [0, interval).
    """
    iv, ph = float(interval), float(phase)
    for _ in range(3):
        tol = iv / BEAT_ALIGN_DIVISOR
        best: "Dict[int, tuple]" = {}
        for t, st in zip(onset_times, strengths):
            k = round((t - ph) / iv)
            if abs(t - (ph + k * iv)) <= tol and (k not in best or st > best[k][1]):
                best[k] = (t, st)
        pairs = [(k, t, max(st, 1e-9) ** 2) for k, (t, st) in best.items()]
        if len(pairs) < 4:
            break
        sw = sum(w for _, _, w in pairs)
        mk = sum(w * k for k, _, w in pairs) / sw
        mt = sum(w * t for _, t, w in pairs) / sw
        sxx = sum(w * (k - mk) ** 2 for k, _, w in pairs)
        if sxx <= 0:
            break
        new_iv = sum(w * (k - mk) * (t - mt) for k, t, w in pairs) / sxx
        if abs(new_iv - interval) > interval / BEAT_ALIGN_DIVISOR:
            break
        # A146: a fit just outside `bpm_range` is held on its bound, not discarded. A tempo that
        # sits on the bound (90 BPM under --beat-range 60-90) fits a hair beyond it as often as
        # inside, and discarding the fit kept the step-rounded interval (89.76 BPM), whose grid
        # was 80 ms off a 30 s click track by its end
        new_iv = min(max(new_iv, 60.0 / hi_bpm), 60.0 / lo_bpm)
        new_ph = mt - new_iv * mk
        moved = abs(new_iv - iv) < 1e-9 and abs(new_ph - ph) < 1e-7
        iv, ph = new_iv, new_ph
        if moved:
            break
    return iv, ph % iv


def beat_grid(envelope: "Sequence[float]", step_s: float, *,
              bpm_range: "Sequence[float]" = (60, 200),
              min_confidence: float = BEAT_MIN_CONFIDENCE,
              duration: "Optional[float]" = None,
              pcm: "Optional[Sequence[float]]" = None,
              pcm_rate: "Optional[int]" = None) -> "Dict[str, Any]":
    """A beat grid from an RMS envelope. Pure: numbers in, a dict out -- no ffmpeg, no I/O.

    Returns {"beats": [t, ...], "tempo_bpm": float|None, "interval": float|None,
             "confidence": 0..1, "onsets": [t, ...], "phase": float,
             "supported": int, "unsupported": int, "usable": bool,
             "method": "rms-flux-autocorrelation", "step_s": step_s, "range_bpm": [lo, hi],
             "onset_refinement": "pcm-window-ratio" | None}

    `step_s` must be the envelope's real step (block samples / rate), not the one asked for:
    every time below is index * step_s. `pcm` and `pcm_rate`, when given, are the samples the
    envelope was built from; each onset is then placed on them (refine_onset_times) instead of at
    the start of its envelope block.

    The method, in full, so a report can quote it:
      1. onset strength = half-wave-rectified first difference of log(env + 1e-9);
      2. onsets = local maxima above median + 1.5 * MAD over a +/-1 s window, 60 ms refractory,
         each placed to 0.25 ms on `pcm` when it is given;
      3. tempo = the best autocorrelation lag of the onset signal inside `bpm_range`, with its
         half and double checked and the one whose onsets align better preferred (octave
         disambiguation: 60, 120 and 240 BPM all autocorrelate on a 120 BPM track);
      4. phase = the offset in [0, interval) at which the grid catches the most onset strength;
         then interval and phase are refitted by least squares to the onsets within interval/8 of
         the grid (_refine_grid), so the tempo is not rounded to a whole number of envelope steps
         (until 3.2.0, at 10 ms, 90 BPM was measured as 0.67 s and the grid drifted 40-90 ms off the
         music over 30 s);
      5. beats = phase + n * interval across the duration (a point within BEAT_ZERO_TOL_S, 10 ms,
         before 0 s is reported at 0.0; one further before is not reported). A grid must be regular, so a grid
         point with no measured onset within interval/4 is still reported -- and counted in
         `unsupported`, so a caller can see how much of the grid the audio actually supports.
         `supported_beats` is the subset that a measured onset does support: it is what a tool
         that MOVES something must snap to, because a regular grid runs on through a passage with
         no music in it and a point moved there was moved to a time nothing in the audio marks;
      6. confidence = 0.5 * clip((z - 2) / 4, 0, 1)
                    + 0.5 * (fraction of onsets within interval/8 of a grid point),
         where z is how many standard deviations the winning autocorrelation lag stands above
         the mean of the others. The plain peak/mean ratio is not used: every signal's
         autocorrelation has a maximum somewhere, so a peak above the mean says nothing -- noise
         scores 2.9 on it, which would read as full confidence.

    A flat or empty envelope has no pulse: confidence 0.0, tempo None, beats []. That is a
    measurement, not a failure -- the caller decides whether 0.0 is enough to act on.
    """
    step_s = float(step_s)
    env = list(envelope or [])
    lo_bpm, hi_bpm = float(min(bpm_range)), float(max(bpm_range))
    out: "Dict[str, Any]" = {
        "beats": [], "supported_beats": [], "tempo_bpm": None, "interval": None,
        "confidence": 0.0, "onsets": [],
        "phase": 0.0, "supported": 0, "unsupported": 0, "usable": False,
        "method": "rms-flux-autocorrelation", "step_s": step_s, "range_bpm": [lo_bpm, hi_bpm],
        "onset_refinement": None,
    }
    if len(env) < 4 or step_s <= 0:
        return out
    total_s = float(duration) if duration else len(env) * step_s

    strength = _onset_strength(env)
    if not any(strength):
        return out
    idx = _pick_onsets(strength, step_s)
    onset_times = [i * step_s for i in idx]
    if pcm and pcm_rate:
        # the PCM the envelope came from places each onset to the sample (refine_onset_times)
        onset_times = refine_onset_times(onset_times, step_s, pcm, int(pcm_rate))
        out["onset_refinement"] = "pcm-window-ratio"
    out["onsets"] = [round(t, 4) for t in onset_times]
    if len(idx) < 2:
        return out

    best_lag, peak, mean_acc, sd_acc = _autocorrelation_peak(strength, step_s, (lo_bpm, hi_bpm))
    if not best_lag or peak <= 0:
        return out
    interval = best_lag * step_s
    strength_at = {i: strength[j] for i, j in enumerate(idx)}

    # Octave disambiguation: try half and double the candidate interval and keep the one whose
    # grid catches the most onset strength per grid point (per point, or a denser grid always wins).
    candidates = [interval]
    for factor in (0.5, 2.0):
        alt = interval * factor
        if 60.0 / hi_bpm <= alt <= 60.0 / lo_bpm:
            candidates.append(alt)

    def best_phase(iv: float) -> "tuple":
        steps = max(4, int(round(iv / step_s)))
        best_ph, best_sc = 0.0, -1.0
        for k in range(steps):
            ph = k * iv / steps
            sc = _grid_score(onset_times, strength_at, iv, ph)
            if sc > best_sc:
                best_ph, best_sc = ph, sc
        return best_ph, best_sc

    # The winner is the grid that explains the most measured onset strength -- "more onsets fall
    # on it", the standard octave rule. An alternative must explain appreciably more (a fifth
    # again) to displace the autocorrelation's own answer: a half-tempo grid catches a subset of
    # the same onsets and a double-tempo grid catches the same set plus empty points, so a bare
    # ">" would flip the answer on noise.
    base_phase, base_score = best_phase(interval)
    interval, phase = interval, base_phase
    for alt in candidates[1:]:
        alt_phase, alt_score = best_phase(alt)
        if alt_score > base_score * BEAT_OCTAVE_MARGIN:
            interval, phase, base_score = alt, alt_phase, alt_score

    # The autocorrelation lag is a whole number of envelope steps, so the interval it gives is the
    # true one rounded to step_s: 90 BPM (0.6667 s) comes out as 0.67 s at 10 ms, 3.3 ms per beat
    # that a phase+n*interval grid accumulates to tens of ms within a bar or two of either end
    # (40-90 ms over 30 s). Refit interval and phase to the onsets themselves (_refine_grid).
    interval, phase = _refine_grid(onset_times, [strength[j] for j in idx], interval, phase,
                                   lo_bpm, hi_bpm)

    beats = []
    # The first grid point at or after 0, where "at" allows BEAT_ZERO_TOL_S (one 10 ms envelope
    # step, the accuracy the grid had before the refit): a track that starts on the beat has no
    # measurable onset at 0 (there is no step before it), so its phase is fitted from the later
    # beats and lands a few ms either side of 0 -- that is the beat at 0.0, not a dropped one. A
    # point further before 0 is not moved there: 0.0 would then be a time the grid does not mark
    # (a 120 BPM grid with phase 0.46 has its point at -0.04 s), and an onset at 0.08 s would make
    # it a "supported" snap target. Indexing by n instead of adding the interval up keeps the
    # float error of a long file out of the last beats.
    n = -1 if phase - interval >= -BEAT_ZERO_TOL_S else 0
    while True:
        t = phase + n * interval
        if t > total_s + 1e-9:
            break
        beats.append(round(max(0.0, t), 4))
        n += 1
    support_tol = interval / BEAT_SUPPORT_DIVISOR
    supported_beats = [b for b in beats
                       if any(abs(b - o) <= support_tol for o in onset_times)]
    supported = len(supported_beats)
    align_tol = interval / BEAT_ALIGN_DIVISOR
    aligned = sum(1 for o in onset_times
                  if min((o - phase) % interval, interval - (o - phase) % interval) <= align_tol)

    # How many spreads the best lag stands above the rest of them, mapped onto [0, 1]: a click
    # track measures z ~= 6, a jittery human performance ~= 5, pseudo-random levels ~= 2.4, so
    # the band [BEAT_Z_FLOOR, BEAT_Z_FLOOR + BEAT_Z_SPAN] = [2, 6] is where the answer changes.
    z = ((peak - mean_acc) / sd_acc) if sd_acc > 0 else 0.0
    periodicity = max(0.0, min(1.0, (z - BEAT_Z_FLOOR) / BEAT_Z_SPAN))
    alignment = aligned / len(onset_times) if onset_times else 0.0
    confidence = round(0.5 * periodicity + 0.5 * alignment, 3)

    out.update({
        "beats": beats, "supported_beats": supported_beats,
        "interval": round(interval, 6), "tempo_bpm": round(60.0 / interval, 2),
        "phase": round(phase, 4), "confidence": confidence, "supported": supported,
        "unsupported": len(beats) - supported,
        "usable": confidence >= float(min_confidence),
    })
    return out


def snap_points(points: "Sequence[float]", beats: "Sequence[float]",
                tolerance: float) -> "List[Dict[str, Any]]":
    """Move each given point to the nearest beat within `tolerance` seconds.

    Pure. Returns [{"from": t, "to": t2, "delta": d, "snapped": bool, "beat_index": i|None}].
    A point with no beat inside `tolerance` is returned unchanged with snapped=False.

    NEVER invents a point: len(out) == len(points), always, and every `to` is either a value that
    was in `beats` or the caller's own `from`. This is the whole no-fabrication rule for beat
    snapping -- a cut point may move to a measured grid point, and may not appear from one.
    """
    grid = sorted(float(b) for b in (beats or []))
    out: "List[Dict[str, Any]]" = []
    for p in points:
        p = float(p)
        best_i, best_d = None, None
        for i, b in enumerate(grid):
            d = abs(b - p)
            if best_d is None or d < best_d:
                best_i, best_d = i, d
        if best_i is not None and best_d is not None and best_d <= float(tolerance):
            out.append({"from": p, "to": grid[best_i], "delta": round(grid[best_i] - p, 6),
                        "snapped": True, "beat_index": best_i})
        else:
            out.append({"from": p, "to": p, "delta": 0.0, "snapped": False, "beat_index": None})
    return out


# ------------------------------------------------------------- filler words (1.17)
#
# A filler word is removed only when a speech engine measured a start/end pair for it. There is no
# heuristic fallback -- no "cut the 0.3 s blips that look like an 'um'", no language guess from the
# filename. Without timings there is nothing to cut, and the tool says so.
#
# What is NOT in these lists is the substance of the decision. "like", "tipo" and "cioè" are
# discourse markers, not disfluencies: they are grammatical words in most sentences, and removing
# them cuts meaning rather than noise. That is a judgement about content, which this skill does not
# make. They are reachable with --filler-extra, and documented as what they are.
FILLER_WORDS = {
    "en": frozenset({"um", "uh", "erm", "hmm", "mm", "mhm", "er", "ah"}),
    # なんか is the most common Japanese filler AND a pronoun/adverb spelled identically. It is in the
    # default list because leaving it out makes --filler useless for Japanese, and every run that
    # removes one warns that it is often a content word (--filler-keep なんか takes it out).
    "ja": frozenset({"えー", "えーと", "えっと", "あの", "あのー", "その", "そのー", "まあ", "なんか"}),
    "es": frozenset({"eh", "este", "esto", "mmm"}),
    "de": frozenset({"äh", "ähm", "hm"}),
    "fr": frozenset({"euh", "hein"}),
    "pt": frozenset({"é", "hum"}),
    "it": frozenset({"ehm"}),
    # 2.19: Korean is written with spaces, so a whisper word is a word and the list works as the
    # English one does. 그/저/뭐/이제 are fillers as often as they are "that"/"I"/"what"/"now":
    # discourse markers below, not defaults.
    "ko": frozenset({"음", "으음", "음음", "어", "어어", "에", "흠"}),
    # Chinese has no spaces: these match only as a whole token with a boundary on each side
    # (filler_spans), so the 额 of 金额 or the 呃 inside a word is never cut. 额 itself is left
    # out: it is a common character in its own right.
    "zh": frozenset({"嗯", "嗯嗯", "呃", "呃呃", "唔"}),
    "ru": frozenset({"э", "ээ", "эм", "эмм", "мм", "хм"}),
    "nl": frozenset({"eh", "ehm", "uh", "uhm", "hm"}),
    "pl": frozenset({"yyy", "yy", "eee", "ee", "em", "emm", "hmm"}),
    "tr": frozenset({"ıı", "ııı", "ee", "eee", "hmm"}),
}

# Words in a default list that are also ordinary vocabulary: every run that removes one says so.
FILLER_AMBIGUOUS = {
    "ja": frozenset({"なんか", "あの", "その", "まあ"}),
    "es": frozenset({"este", "esto"}),
    "pt": frozenset({"é"}),
}

# Discourse markers people ask for by name. Not defaults; named here so --help and the docs can
# say what adding one costs.
FILLER_DISCOURSE_MARKERS = {
    "en": ("like", "you know"),
    "pt": ("tipo",),
    "it": ("cioè",),
    "ko": ("그", "저", "뭐", "이제", "약간", "막", "그니까"),
    "zh": ("那个", "这个", "就是", "然后"),
    "ru": ("ну", "типа", "короче", "как бы"),
    "nl": ("nou", "dus", "zeg maar"),
    "pl": ("no", "jakby", "wiesz", "znaczy"),
    "tr": ("şey", "yani", "işte"),
}

FILLER_MAX_WORD = 1.2   # a longer "uhhh" is a held vowel someone meant
FILLER_MIN_GAP = 0.05   # spans closer than this become one span
FILLER_PAD = 0.02       # trimmed either side of the word
FILLER_MAX_TOKENS = 4   # a listed word may span this many engine tokens ("えー" + "と", "you" + "know")
FILLER_BOUNDARY_GAP = 0.1  # a pause this long between two tokens is a word boundary


def _unspaced_script(text: str) -> bool:
    """True when `text` has a character of a script written without spaces between words (Han,
    kana, Thai, Lao, Myanmar, Khmer). Whisper splits those languages into tokens, not words, so a
    token boundary there says nothing about a word boundary. Hangul is spaced and not listed."""
    for ch in text:
        o = ord(ch)
        if (0x3040 <= o <= 0x30FF or 0x31F0 <= o <= 0x31FF or 0xFF66 <= o <= 0xFF9F   # kana
                or 0x3400 <= o <= 0x4DBF or 0x4E00 <= o <= 0x9FFF or 0xF900 <= o <= 0xFAFF  # Han
                or 0x20000 <= o <= 0x323AF  # Han extensions B-H
                or 0x0E00 <= o <= 0x0EFF or 0x1000 <= o <= 0x109F or 0x1780 <= o <= 0x17FF):  # Thai, Lao, Myanmar, Khmer
            return True
    return False


def normalise_filler_token(word: str) -> str:
    """A spoken token stripped to what a word list can be compared against: case-folded, with
    surrounding punctuation and whitespace removed. Never a substring match -- "umbrella" must
    survive a list containing "um"."""
    import unicodedata as _ud
    text = str(word or "").strip()
    text = "".join(ch for ch in text
                   if not _ud.category(ch).startswith("P") or ch in "-'’")
    return text.strip("-'’").casefold()


def filler_spans(words, wordlist, *, pad: float = FILLER_PAD, min_gap: float = FILLER_MIN_GAP,
                 max_word: float = FILLER_MAX_WORD, stats: "Optional[Dict[str, int]]" = None) -> "List[Dict[str, Any]]":
    """Time spans to remove, from measured word timings. Pure: no subprocess, no I/O.

    `words` is [{"word", "start", "end"}] as whisper emits. A run of up to FILLER_MAX_TOKENS
    consecutive entries is removed only when the run, joined with or without spaces and
    normalised, is in `wordlist` AND every entry carries a real start < end pair AND the run is
    <= max_word long. The longest run wins. Adjacent spans closer than min_gap merge. Returns
    [{"start", "end", "word"}] sorted and non-overlapping.

    Whisper splits Chinese, Japanese and Thai into tokens rather than words ("えーと" arrives as
    "えー" + "と", "金额" as "金" + "额"), so a run in such a script also needs a word boundary on
    each side: the start or end of the transcript, punctuation, a spaced-script neighbour, or a
    pause of FILLER_BOUNDARY_GAP. Without one the run is part of a longer word and is kept.

    `stats`, when given, receives the listed words that were kept anyway, so the caller can say
    so: `matched_untimed` (no usable start < end: nothing to cut on) and `matched_too_long`
    (longer than max_word: a held vowel someone meant).
    """
    import unicodedata as _ud
    listed = {normalise_filler_token(w) for w in (wordlist or set())}
    listed.discard("")
    toks = []
    for entry in words or []:
        if not isinstance(entry, dict):
            continue
        raw = str(entry.get("word") or entry.get("text") or "").strip()
        try:
            start, end = float(entry["start"]), float(entry["end"])
            timed = end > start
        except (KeyError, TypeError, ValueError):
            start = end = 0.0
            timed = False
        toks.append({"norm": normalise_filler_token(raw), "start": start, "end": end, "timed": timed,
                     "punct_before": bool(raw) and _ud.category(raw[0]).startswith("P"),
                     "punct_after": bool(raw) and _ud.category(raw[-1]).startswith("P")})

    def _bounded(i: int, j: int) -> bool:
        """A word boundary before toks[i] and after toks[j - 1]."""
        left = (i == 0 or toks[i]["punct_before"] or toks[i - 1]["punct_after"] or not toks[i - 1]["norm"]
                or not _unspaced_script(toks[i - 1]["norm"])
                or (toks[i - 1]["timed"] and toks[i]["start"] - toks[i - 1]["end"] >= FILLER_BOUNDARY_GAP - 1e-6))
        right = (j == len(toks) or toks[j - 1]["punct_after"] or toks[j]["punct_before"] or not toks[j]["norm"]
                 or not _unspaced_script(toks[j]["norm"])
                 or (toks[j]["timed"] and toks[j]["start"] - toks[j - 1]["end"] >= FILLER_BOUNDARY_GAP - 1e-6))
        return left and right

    hits = []
    untimed = too_long = 0
    i = 0
    while i < len(toks):
        found = 0
        rejected = None
        for k in range(min(FILLER_MAX_TOKENS, len(toks) - i), 0, -1):
            run = toks[i:i + k]
            norms = [t["norm"] for t in run]
            if not all(norms):
                continue
            unspaced = any(_unspaced_script(n) for n in norms)
            joined = ("" if unspaced else " ").join(norms)
            if joined not in listed or (unspaced and not _bounded(i, i + k)):
                continue
            # punctuation inside the run ("えー、" + "と") ends the word: the shorter run decides
            if any(run[m]["punct_after"] or run[m + 1]["punct_before"] for m in range(k - 1)):
                continue
            # so does a pause inside an unspaced run: the tokens were two words
            if unspaced and any(run[m]["timed"] and run[m + 1]["timed"]
                                and run[m + 1]["start"] - run[m]["end"] >= FILLER_BOUNDARY_GAP - 1e-6
                                for m in range(k - 1)):
                continue
            # a run listed out of time order has no span to cut on
            if not all(t["timed"] for t in run) or run[-1]["end"] <= run[0]["start"]:
                rejected = rejected or ("untimed", k)
                continue
            if run[-1]["end"] - run[0]["start"] > max_word:
                rejected = rejected or ("too_long", k)
                continue
            hits.append({"start": max(0.0, run[0]["start"] - pad), "end": run[-1]["end"] + pad, "word": joined})
            found = k
            break
        if not found and rejected:
            # the longest listed run that could not be cut is the one reported. Its prefixes were
            # tried here; moving on by one token lets a listed word later in it be tried too
            untimed += rejected[0] == "untimed"
            too_long += rejected[0] == "too_long"
            found = 1
        i += found or 1
    hits.sort(key=lambda h: (h["start"], h["end"]))
    merged: "List[Dict[str, Any]]" = []
    for h in hits:
        if merged and h["start"] - merged[-1]["end"] <= min_gap:
            merged[-1]["end"] = max(merged[-1]["end"], h["end"])
            merged[-1]["word"] = merged[-1]["word"] + " " + h["word"]
        else:
            merged.append(dict(h))
    for m in merged:
        m["start"] = round(m["start"], 4)
        m["end"] = round(m["end"], 4)
    if stats is not None:
        stats["matched_untimed"] = untimed
        stats["matched_too_long"] = too_long
    return merged


# --- 1.18.0: lightweight block-matching motion estimate (scenes.py --shots, cropdetect.py
# --motion-centre) ---------------------------------------------------------------------------

MOTION_GRID = 4          # NxN anchor blocks per frame
MOTION_SEARCH = 3         # +/- pixels searched per block, at the decoded (low) resolution
MOTION_STATIC_PX = 0.35   # average per-frame displacement below this, at decode resolution, is "static"
MOTION_PAN_SPREAD = 0.6   # block-to-block direction agreement above this (0..1) reads as a pan


def _block_match(prev: bytes, cur: bytes, w: int, h: int, cx: int, cy: int, half: int, search: int) -> "Tuple[float, float]":
    """(dx, dy) that best aligns a `half*2` square centred at (cx, cy) in `prev` to `cur`,
    searched over +/- `search` px by sum-of-absolute-differences. Coordinates and the returned
    offset are in decoded-frame pixels (a handful of pixels a side at 1.18.0's sample size)."""
    x0, y0 = max(half, min(w - half - 1, cx)), max(half, min(h - half - 1, cy))
    ref = [prev[(y0 + dy) * w + (x0 + dx)] for dy in range(-half, half + 1) for dx in range(-half, half + 1)]

    def sad_at(xx: int, yy: int) -> "Optional[int]":
        if xx - half < 0 or xx + half >= w or yy - half < 0 or yy + half >= h:
            return None
        sad = 0
        for dy in range(-half, half + 1):
            row = (yy + dy) * w
            for dx in range(-half, half + 1):
                sad += abs(ref[(dy + half) * (2 * half + 1) + (dx + half)] - cur[row + xx + dx])
        return sad

    # Zero shift is the tie-break candidate, not the search order's first cell: on a textureless
    # block (a flat colour, sky, an out-of-focus background) every offset scores the same SAD, and
    # without an explicit tie towards "no motion" the scan used to report the search window's
    # first corner as the measured displacement -- a still frame with nothing to match against
    # read as steady motion in one direction, every time.
    best_sad, best = sad_at(x0, y0), (0.0, 0.0)
    if best_sad is None:
        best_sad = float("inf")
    for sy in range(-search, search + 1):
        for sx in range(-search, search + 1):
            if sx == 0 and sy == 0:
                continue
            sad = sad_at(x0 + sx, y0 + sy)
            if sad is not None and sad < best_sad:
                best_sad, best = sad, (float(sx), float(sy))
    return best


def frame_flow(prev: bytes, cur: bytes, w: int, h: int, *, grid: int = MOTION_GRID,
               search: int = MOTION_SEARCH) -> "Dict[str, Any]":
    """One measurement between two consecutive decoded grayscale frames: the mean block
    displacement vector, its magnitude, and how consistently the blocks agree on direction
    (0 = every block moved a different way, 1 = every block agrees -- a pan or dolly moves the
    whole frame one way, on-screen motion inside a mostly-static frame does not)."""
    half = max(1, min(w, h) // (grid * 3))
    vecs: "List[Tuple[float, float]]" = []
    for gy in range(grid):
        for gx in range(grid):
            cx = int((gx + 0.5) * w / grid)
            cy = int((gy + 0.5) * h / grid)
            vecs.append(_block_match(prev, cur, w, h, cx, cy, half, search))
    mdx = sum(v[0] for v in vecs) / len(vecs)
    mdy = sum(v[1] for v in vecs) / len(vecs)
    magnitude = math.hypot(mdx, mdy)
    mean_len = sum(math.hypot(*v) for v in vecs) / len(vecs)
    agreement = (magnitude / mean_len) if mean_len > 1e-6 else 1.0  # 1.0 = every block agrees
    return {"dx": mdx, "dy": mdy, "magnitude": magnitude, "agreement": min(1.0, agreement)}


def label_shot_flow(flows: "Sequence[Dict[str, Any]]") -> "Dict[str, Any]":
    """{label, flow_magnitude} for one shot from its per-frame-pair flow measurements.

    static: mean displacement below MOTION_STATIC_PX. pan: above it, and blocks agree on
    direction (a camera move shifts the whole frame). motion: above it, blocks disagree (motion
    inside an otherwise still frame -- handheld jitter, or a subject moving across a static
    background). This is a measured proxy, the same spirit as scenes.py --rank-by: it reports
    what a coarse block match saw, not what is interesting about the shot."""
    if not flows:
        return {"label": "static", "flow_magnitude": 0.0}
    magnitude = sum(f["magnitude"] for f in flows) / len(flows)
    agreement = sum(f["agreement"] for f in flows) / len(flows)
    if magnitude < MOTION_STATIC_PX:
        label = "static"
    elif agreement >= MOTION_PAN_SPREAD:
        label = "pan"
    else:
        label = "motion"
    return {"label": label, "flow_magnitude": round(magnitude, 3)}
