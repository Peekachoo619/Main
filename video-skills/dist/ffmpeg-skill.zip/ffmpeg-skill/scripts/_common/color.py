"""Colour: the bt709 tagging arguments and the HDR-to-SDR conversion path, plus colour-token
validation for the tools that take a `--color`.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Sequence, Tuple
from _common.emit import die
from _common.runner import ffmpeg_version


def bt709_tag_args(encoder: str = "libx264") -> List[str]:
    """Tag an SDR output as BT.709 without touching its pixels.

    Up to FFmpeg 7.0 the output options -colorspace/-color_primaries/-color_trc were tags only.
    7.1 added colourspace negotiation to libavfilter and feeds those options into the graph's
    output constraints, so on a source whose bitstream carries no colour tags (test sources,
    screen recordings, many cameras) the CLI now auto-inserts a *real* matrix conversion (its
    guess for "unknown" is bt601) into every SDR re-encode: a --lut-strength 0 no-op grade
    came back ~24 dB PSNR from its source on 7.1. From 7.1 on, the tags therefore go through
    the encoder's own VUI parameters instead, which libavfilter never sees.

    These tags are a label on every FFmpeg version: they never convert the pixels. A source
    whose matrix is not BT.709 (a BT.601 `smpte170m`/`bt470bg` file) gets its pixels converted
    separately, by bt709_matrix_filter() in the filter graph; through 2.10.0 nothing did, and
    such a source came out labelled BT.709 over BT.601 pixels (measured on 6.1: 48.5 dB YUV
    PSNR against the source, i.e. untouched, tagged bt709/bt709/bt709).
    """
    if ffmpeg_version() < (7, 1):
        return ["-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709"]
    if encoder == "libx265":
        return ["-x265-params", "colorprim=bt709:transfer=bt709:colormatrix=bt709"]
    return ["-x264-params", "colorprim=bt709:transfer=bt709:colormatrix=bt709"]


def _sdr_bt709(encoder: str) -> "Tuple[str, List[str]]":
    """BT.709 SDR tags for `encoder` as (encoder-params string, extra output options): the two
    spellings bt709_tag_args() picks between, split so a caller that already builds an encoder
    params string can merge them (the option given twice keeps only the last)."""
    if ffmpeg_version() < (7, 1):
        return "", ["-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709"]
    if encoder == "libsvtav1":
        return "color-primaries=1:transfer-characteristics=1:matrix-coefficients=1", []
    if encoder == "libaom-av1":
        return "", []  # no VUI params option; an untagged 8-bit stream reads as BT.709 everywhere
    return "colorprim=bt709:transfer=bt709:colormatrix=bt709", []


# The SDR matrices (ffprobe's names) whose pixels an output tagged BT.709 has to convert:
# BT.601 (`smpte170m` 525-line, `bt470bg` 625-line: the same coefficients) and the two rare
# pre-BT.709 ones the colorspace filter also reads. bt2020nc/c sources take the HDR/BT.2020 path.
NON_BT709_MATRICES = ("smpte170m", "bt470bg", "fcc", "smpte240m")

# RGB pictures (ffprobe's pix_fmt names: PNG rgb24/rgba/pal8/rgb48be, qtrle, gbrp...). Their
# conversion to YUV is wherever the graph first needs YUV, and FFmpeg's default for it is BT.601
# (5.1, 6.1, 7.0; 7.1+ follows the link's tag, unspecified = BT.601). Gray has no matrix.
_RGB_PIX_FMT_RE = re.compile(r"^(?:rgb|bgr|argb|abgr|0rgb|0bgr|gbr|x2rgb|x2bgr|pal8)")


# A probed colour tag passed back to FFmpeg (#454). ffprobe prints av_color_*_name(), which is
# also the setparams filter's table; the output options -colorspace/-color_primaries/-color_trc
# parse an older one that differs on three names (6.1, measured): -colorspace refuses `gbr` (its
# name is `rgb`) and -color_trc refuses `bt470m` and `bt470bg` (its names: `gamma22`, `gamma28`).
# `gbr` is not carried over at all: it says the stored samples are RGB, which is the pixel
# format's to say (the PNG encoder tags it itself), and a tool that converts the picture to YUV on
# the way (a grade's legs, a 4:4:4 alpha line) would label YUV samples as RGB with it.
_TAG_KIND = {"-colorspace": "colorspace", "-color_primaries": "color_primaries", "-color_trc": "color_trc"}
_OPTION_NAMES = {"color_trc": {"bt470m": "gamma22", "bt470bg": "gamma28"}}


def carried_tag(kind: str, name: Optional[str], dest: str = "option") -> Optional[str]:
    """The probed tag `name` of `kind` (colorspace, color_primaries, color_trc) spelled the way
    `dest` ("option": -colorspace & co; "setparams") accepts it, or None when it is not to be
    passed on: unknown, unspecified, reserved, or the RGB `gbr`/`rgb`."""
    if not name or name in ("unknown", "unspecified", "reserved") or (kind == "colorspace" and name in ("gbr", "rgb")):
        return None
    return _OPTION_NAMES.get(kind, {}).get(name, name) if dest == "option" else name


def carried_tag_args(pairs: Sequence[Tuple[str, Optional[str]]]) -> List[str]:
    """[flag, value, ...] for each (flag, probed name) whose tag carried_tag() passes on."""
    out: List[str] = []
    for flag, name in pairs:
        value = carried_tag(_TAG_KIND.get(flag, flag.lstrip("-")), name)
        if value:
            out += [flag, value]
    return out


def rgb_to_bt709_filter(pix_fmt: str = "yuv444p") -> str:
    """An RGB picture converted to BT.709 limited-range YUV right here, in `pix_fmt`, so no later
    conversion (an auto-inserted one, with FFmpeg's BT.601 default) decides the matrix. 4:4:4 by
    default: the tool's own scaling and the encoder's 4:2:0 come after, as they did on the RGB."""
    return f"scale=out_color_matrix=bt709:out_range=tv,format={pix_fmt}"


def is_rgb(meta: Optional[Dict[str, Any]]) -> bool:
    """True when the probed picture is RGB (a PNG/still, a qtrle/png-in-mov clip, an image sequence)."""
    return bool(_RGB_PIX_FMT_RE.match(str(((meta or {}).get("video") or {}).get("pix_fmt") or "")))


# The matrices (ffprobe's names) swscale can be told to make YUV with, by its own name for each
# (scale's out_color_matrix). A BT.2020/HDR line tags one of these on an RGB source (#544).
_SWS_OUT_MATRIX = {"bt2020nc": "bt2020", "bt709": "bt709", "smpte170m": "bt601", "bt470bg": "bt601",
                   "fcc": "fcc", "smpte240m": "smpte240m"}


def hdr_line_matrix(v: Optional[Dict[str, Any]]) -> str:
    """The matrix tag (ffprobe's name) a 10-bit line that keeps a BT.2020 / HDR source's colour
    writes for the probed video `v`: a YUV source's own, or bt2020nc when it has none, as always.

    An RGB source has no matrix: its tag is `gbr` (FFV1, PNG, qtrle, libx264rgb and most RGB
    codecs write it) or nothing, and the YUV the line stores is made by a conversion. Through
    3.10.0 the line passed the tag on (`-colorspace gbr`, which no encoder parses: every re-encode
    of such a source failed inside ffmpeg) or wrote bt2020nc over FFmpeg's default conversion,
    BT.601 (#544). For an RGB source the tag is the matrix hdr_rgb_matrix_filter() converts with:
    the source's own when it names one swscale can make (a mislabelled RGB file, whose frames
    FFmpeg 6.1 already converted by that tag), else bt2020nc."""
    v = v or {}
    cs = v.get("color_space")
    if _RGB_PIX_FMT_RE.match(str(v.get("pix_fmt") or "")):
        return cs if cs in _SWS_OUT_MATRIX else "bt2020nc"
    return cs or "bt2020nc"


def hdr_rgb_matrix_filter(meta: Optional[Dict[str, Any]], line_meta: Optional[Dict[str, Any]] = None, alpha: bool = False) -> Optional[str]:
    """For an RGB source that probes BT.2020 or HDR, written on a line that keeps that colour
    (video_args' Main10 / 10-bit lines; `line_meta`: the probe the line was chosen for when it is
    another picture's, as in a join; `alpha`: an alpha line, which keeps the plane): the filter that makes its YUV with the matrix the line tags
    (hdr_line_matrix), limited range, 4:4:4 at the line's 10 bits, so no later conversion (an
    auto-inserted one, with FFmpeg's BT.601 default) decides the matrix. None for every other
    source, and when the line's matrix is one swscale cannot be told to make (bt2020c, ICtCp).

    Only the matrix is named. Primaries and transfer are the source's and stay as they are (the
    line tags them), so the picture is the source's RGB read back by the output's own tags
    (measured on FFmpeg 6.1.1: C03028 came back 196/52/35 before, 192/48/40 after)."""
    v = (meta or {}).get("video") or {}
    if not v.get("bt2020_or_hdr") or not is_rgb(meta):
        return None
    line_v = v if line_meta is None else (line_meta.get("video") or {})
    if not line_v.get("bt2020_or_hdr"):
        return None
    matrix = _SWS_OUT_MATRIX.get(hdr_line_matrix(line_v))
    if matrix is None:
        return None
    # a palette is turned into YUV with fixed BT.601 coefficients whatever out_color_matrix says
    return ("format=rgb24," if v.get("pix_fmt") == "pal8" else "") + f"scale=out_color_matrix={matrix}:out_range=tv,format=yuv{'a' * alpha}444p10le"


# An odd-sized BT.601 source is padded to even for the colorspace filter and cropped back to its
# own size after it (bt709_matrix_filter): both wrap the conversion in the one -vf the merge finds.
_EVEN_PAD = "pad=ceil(iw/2)*2:ceil(ih/2)*2:0:0,"
_BT709_RELABEL = "setparams=color_primaries=bt709:color_trc=bt709"
_MATRIX_FILTER_RE = re.compile(r"^(?:(?:(?:%s)?colorspace=ispace=(?:%s):iprimaries=bt709:itrc=bt709:space=bt709:primaries=bt709:trc=bt709(?:,crop=iw-[01]:ih-[01]:0:0:exact=1)?|(?:format=rgb24,)?%s"
                               r"|(?:format=rgb24,)?scale=out_color_matrix=(?:%s):out_range=tv,format=yuva?444p10le)(?:,%s)?|%s)$"
                               % (re.escape(_EVEN_PAD), "|".join(NON_BT709_MATRICES), re.escape(rgb_to_bt709_filter()),
                                  "|".join(sorted(set(_SWS_OUT_MATRIX.values()))), re.escape(_BT709_RELABEL), re.escape(_BT709_RELABEL)))
# [N:v], [N:v:0] and [N:V:0] (PROBED_VIDEO: the motion picture, not an attached cover)
_INPUT_VIDEO_REF = re.compile(r"\[(\d+):[vV](?::0)?\]")


def bt709_matrix_filter(meta: Optional[Dict[str, Any]]) -> Optional[str]:
    """The filter that turns the probed source's pixels into BT.709 ones before an output is
    tagged BT.709, or None when nothing needs converting: a source tagged with a non-BT.709 matrix
    (NON_BT709_MATRICES) or an RGB one. An untagged or BT.709 source, an HDR/BT.2020 YUV one (it
    keeps its own tags, or color.py --to-sdr converts it) and a missing probe get None, so their
    commands are what they were.

    The matrix is converted and nothing else: primaries and transfer are passed through
    (iprimaries/itrc = the output's), so the picture a player that decodes with the source's
    matrix showed is the picture the BT.709 output shows. The `colorspace` filter is in every
    FFmpeg build (no zscale needed) and takes explicit input properties, so the conversion does
    not depend on how a build reads or negotiates the frames' own tags. The range is left as it is.

    An RGB source (is_rgb: a PNG/still, an image sequence, a qtrle clip) has no matrix of its own
    but gets one where the graph first needs YUV, and FFmpeg's default there is BT.601: through
    2.10.1 such a source came out labelled BT.709 over BT.601-encoded pixels (pure red decoded as
    (255,24,0), pure green as (0,216,0), on 5.1.1 to 8.1). It is converted to BT.709 YUV here
    (rgb_to_bt709_filter), an HDR or BT.2020 RGB one too (#559): the tag names the matrix whatever
    the primaries and transfer are (the HDR line's own conversion is hdr_rgb_matrix_filter). A JPEG
    (yuvj, tagged bt470bg) is a BT.601 source like any other."""
    v = (meta or {}).get("video") or {}
    matrix = v.get("color_space")
    if v.get("bt2020_or_hdr") and not is_rgb(meta):
        return None
    if is_rgb(meta):
        # a palette is turned into YUV with fixed BT.601 coefficients whatever out_color_matrix
        # says (5.1.1, 6.1): expand it to RGB first
        return ("format=rgb24," if v.get("pix_fmt") == "pal8" else "") + rgb_to_bt709_filter()
    if matrix not in NON_BT709_MATRICES:
        return None
    # the colorspace filter refuses an odd width or height outright ("Invalid odd size"), and a
    # 4:2:0 JPEG can have one (a phone screenshot, #437). The frame is padded by one row and/or
    # column, converted, and cropped back to its own size: no source pixel is lost or resampled
    # (a 4:2:0 frame's chroma planes are the same size either way), so a caller's own crop or
    # scale sees the frame it measured. Nothing changes for an even-sized source. FFmpeg rotates
    # a rotated source before the graph, so the odd axis is read after the same swap.
    w, h = int(v.get("width") or 0), int(v.get("height") or 0)
    if int(v.get("rotation") or 0) % 180 == 90:
        w, h = h, w
    conv = f"colorspace=ispace={matrix}:iprimaries=bt709:itrc=bt709:space=bt709:primaries=bt709:trc=bt709"
    if w % 2 or h % 2:
        return f"{_EVEN_PAD}{conv},crop=iw-{w % 2}:ih-{h % 2}:0:0:exact=1"
    return conv


def bt709_label_filter(meta: Optional[Dict[str, Any]]) -> Optional[str]:
    """For an UNTAGGED SDR YUV picture that meets a converted (BT.709-tagged) one in a filter that
    mixes pictures (overlay, xstack): its BT.709 label, tags only (setparams), or None for any
    other picture (tagged, RGB, HDR, no probe).

    FFmpeg 7.1+ negotiates one colourspace for all of a mixing filter's inputs and converts the
    others to it, taking "unknown" as BT.601: the untagged main under a converted logo, or an
    untagged grid cell beside a converted one, was shifted (7.08 mean / 25 max RGB on 7.1.1 and
    8.1.3), or the converted picture converted back. Labelled as what the output says it is, the
    inputs agree and nothing is converted; on 5.1-7.0 the label changes nothing. The pixels are not
    touched, as for the untagged source of a one-input re-encode (bt709_tag_args)."""
    v = (meta or {}).get("video") or {}
    if (not v.get("pix_fmt") or v.get("bt2020_or_hdr") or is_rgb(meta)
            or (v.get("color_space") or "unknown") not in ("unknown", "unspecified")):
        return None
    return "setparams=colorspace=bt709" + ("" if v.get("color_range") == "pc" else ":range=tv")


# FFmpeg's named colours that are greys (libavutil/parseutils.c's table): R = G = B.
_GREY_NAMES = frozenset(("black", "white", "gray", "grey", "silver", "darkgray", "darkgrey", "dimgray", "dimgrey",
                         "gainsboro", "lightgray", "lightgrey", "whitesmoke"))


def _yuv8(rgb: Sequence[int], kr: float, kb: float) -> "Tuple[int, int, int]":
    """8-bit limited-range YUV of an RGB colour under the matrix (kr, kb), rounded as FFmpeg's
    drawing code rounds it (ff_draw_color)."""
    r, g, b = (c / 255 for c in rgb)
    y = kr * r + (1 - kr - kb) * g + kb * b
    return (int(16 + 219 * y + 0.5), int(128 + 224 * (b - y) / (2 * (1 - kb)) + 0.5),
            int(128 + 224 * (r - y) / (2 * (1 - kr)) + 0.5))


def is_neutral_color(value: Any) -> bool:
    """True for a colour whose 8-bit YUV is the same under BT.601 and BT.709, however translucent: a
    grey (R = G = B; black and white included), or one so near grey that both round to the same
    bytes (graphics.py's default background 101418). Only another colour lands differently, so only
    it needs drawn_chain(). A name counts only if it is one of FFmpeg's greys; anything else
    (`red`, `random`) is not neutral."""
    v = str(value or "").strip().split("@")[0].lower()
    if v in _GREY_NAMES:
        return True
    v = v[1:] if v.startswith("#") else v[2:] if v.startswith("0x") else v
    if re.fullmatch(r"[0-9a-f]{6}(?:[0-9a-f]{2})?", v):
        rgb = (int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16))
        return _yuv8(rgb, 0.299, 0.114) == _yuv8(rgb, 0.2126, 0.0722)
    return False


def is_full_range(meta: Optional[Dict[str, Any]]) -> bool:
    """True when the probed YUV picture is full range: a `yuvj` format, or any other YUV format
    tagged `pc` (VP9 and AV1 full range decode as plain `yuv420p` tagged pc, 10-bit full range as
    `yuv420p10le` tagged pc). An RGB picture is not: bt709_matrix_filter() makes it limited YUV."""
    v = (meta or {}).get("video") or {}
    if is_rgb(meta) or not v.get("pix_fmt"):
        return False
    return str(v["pix_fmt"]).startswith("yuvj") or v.get("color_range") == "pc"


def limited_range_filter(meta: Optional[Dict[str, Any]]) -> Optional[str]:
    """The filter that takes a full-range SDR YUV picture (is_full_range) to limited range, or None
    for any other picture (limited, RGB, HDR/BT.2020, no probe).

    A tool that puts several pictures in one frame or one stream (concat, xfade, xstack, overlay)
    passes their samples through as they are, so a full-range clip beside a limited one was shown
    with the other's range: C03028 came out C9251B (#410). The input range is left to `scale`,
    which reads it from each frame (FFmpeg 6.1 already converts a full-range non-`yuvj` frame to
    limited at any resize, so a stated `in_range=pc` would convert some frames twice); only the
    output range is stated. A `yuvj` format is full range by name, so it is also given its limited
    name (`format=`), or swscale would write full range under the limited tag."""
    v = (meta or {}).get("video") or {}
    if v.get("bt2020_or_hdr") or not is_full_range(meta):
        return None
    pf = str(v["pix_fmt"])
    return "scale=out_range=tv" + (f",format=yuv{pf[4:]}" if pf.startswith("yuvj") else "")


def as_limited(meta: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """`meta` as it reads after limited_range_filter(): the same probe with a limited-range format and
    tag, for the code that plans what is drawn on the converted picture (drawn_stream_format)."""
    if not limited_range_filter(meta):
        return meta
    v = dict((meta or {}).get("video") or {})
    pf = str(v["pix_fmt"])
    v.update(pix_fmt="yuv" + pf[4:] if pf.startswith("yuvj") else pf, color_range="tv")
    return {**(meta or {}), "video": v}


def drawn_stream_format(meta: Optional[Dict[str, Any]]) -> "Tuple[str, bool]":
    """(pix_fmt, full range) of the picture a tool draws on, for rgb_island(): the probed source's own
    8-bit planar YUV format (an RGB source has become yuv444p, BT.709 limited, through
    bt709_matrix_filter), or yuv420p for anything else (the format the encoder line takes it to)."""
    v = (meta or {}).get("video") or {}
    if is_rgb(meta):
        return "yuv444p", False
    pf = str(v.get("pix_fmt") or "yuv420p")
    full = is_full_range(meta)
    if pf not in ("yuv420p", "yuv422p", "yuv444p", "yuvj420p", "yuvj422p", "yuvj444p"):
        pf = "yuv420p"
    return pf, full


def rgb_island(colour_chain: str, neutral_chain: str = "null", pix_fmt: str = "yuv420p", full: bool = False,
               tag: str = "d") -> str:
    """`colour_chain` (filters that draw a colour: drawtext, pad, tpad, rotate's fill, libass) run on
    an RGB copy of the picture, as one simple filtergraph (one input, one output; `tag` keeps its
    labels unique in a bigger graph). For FFmpeg < 7.1, whose drawing filters turn every colour into
    YUV with BT.601 whatever the picture is tagged (`ff_draw_init`), and drawbox on every version:
    in RGB a colour is written as it is, and the copy goes back to YUV with BT.709.

    Only the pixels the drawing touched come from that copy. The same round trip without the colour
    (`neutral_chain`: `null`, or the same pad/tpad/rotate with a black fill, which is the same under
    every matrix) is compared with it plane by plane, and maskedmerge takes the drawn copy where
    the two differ and the untouched picture (`neutral_chain` on the YUV itself) everywhere else:
    the RGB round trip is not lossless, so a picture that only passes through keeps its pixels."""
    rng = "pc" if full else "tv"
    to_rgb = f"scale=in_color_matrix=bt709:in_range={rng},format=rgb24"
    to_yuv = f"scale=out_color_matrix=bt709:out_range={rng},format={pix_fmt}"
    keep = "'255*gt(val,0)'"
    t = f"_{tag}"
    return (f"split=3[{t}p][{t}c][{t}n];[{t}p]format={pix_fmt},{neutral_chain}[{t}p1];"
            f"[{t}c]{to_rgb},{colour_chain},{to_yuv},split[{t}c1][{t}c2];"
            f"[{t}n]{to_rgb},{neutral_chain},{to_yuv}[{t}n1];"
            f"[{t}c1][{t}n1]blend=all_mode=difference,lut=c0={keep}:c1={keep}:c2={keep}[{t}m];"
            f"[{t}p1][{t}c2][{t}m]maskedmerge")


def bt709_matrix_args(meta: Optional[Dict[str, Any]]) -> List[str]:
    """["-vf", bt709_matrix_filter(meta)] for an encoder line that tags its output BT.709, or [].

    It rides on the encoder line (decision.video_args() and friends) so every tool that
    re-encodes through that line converts without building it into its own graph. That -vf is
    valid as it stands for a command with no other filter; run() folds it into the tool's own
    -vf or -filter_complex (fold_bt709_matrix()) before the command is recorded or run."""
    f = bt709_line_filter(meta)
    return ["-vf", f] if f else []


# bt709_matrix_filter(), and on FFmpeg 9+ for an HDR source a relabel: FFmpeg 9 writes mp4/mov's colr box
# from the frames, which keep its primaries and transfer under a bt709 VUI (#711). It converts nothing.
def bt709_line_filter(meta: Optional[Dict[str, Any]]) -> Optional[str]:
    f = bt709_matrix_filter(meta)
    if ((meta or {}).get("video") or {}).get("bt2020_or_hdr") and ffmpeg_version() >= (9, 0):
        f = ",".join(x for x in (f, _BT709_RELABEL) if x)
    return f


def hdr_rgb_matrix_args(meta: Optional[Dict[str, Any]], alpha: bool = False) -> List[str]:
    """["-vf", hdr_rgb_matrix_filter(meta)] for an encoder line that keeps a BT.2020 / HDR source's
    colour, or []: bt709_matrix_args()'s counterpart for that line, folded by run() the same way."""
    f = hdr_rgb_matrix_filter(meta, alpha=alpha)
    return ["-vf", f] if f else []


def fold_bt709_matrix(cmd: Sequence[str]) -> List[str]:
    """`cmd` with the conversion bt709_matrix_args() appended to its encoder line moved into the
    tool's own filter graph, where it runs first, on the decoded source:

    - no other filter: unchanged (the -vf is the graph);
    - a -vf: the conversion is prepended to that chain;
    - a -filter_complex: every `[N:v]` / `[N:v:0]` / `[N:V:0]` reference to an input that reads the same file
      as input 0 (the file the encoder line was built for; cut.py's segment join opens it once
      per segment) reads that input through the conversion instead. Other inputs are untouched.

    A -filter_complex with no such reference is refused rather than run with two graphs (ffmpeg
    would refuse it anyway, less clearly). Every other command is returned as it is."""
    out: List[str] = []
    conv, at = None, -1
    i = 0
    while i < len(cmd):
        if cmd[i] == "-vf" and i + 1 < len(cmd) and _MATRIX_FILTER_RE.match(str(cmd[i + 1])):
            conv, at = conv or str(cmd[i + 1]), (at if at >= 0 else len(out))
            i += 2
            continue
        out.append(cmd[i])
        i += 1
    if conv is None:
        return list(cmd)
    graph_at = next((k for k, a in enumerate(out[:-1]) if a in ("-filter_complex", "-lavfi")), None)
    if graph_at is not None:
        inputs = [out[k + 1] for k in range(len(out) - 1) if out[k] == "-i"]
        source = {n for n, p in enumerate(inputs) if p == inputs[0]} if inputs else set()
        refs: Dict[int, List[str]] = {}  # input index -> [its first reference, the labels standing in for it]

        def through(m: "re.Match[str]") -> str:
            n = int(m.group(1))
            if n not in source:
                return m.group(0)
            label = f"[bt709src{sum(len(v) - 1 for v in refs.values())}]"
            refs.setdefault(n, [m.group(0)]).append(label)
            return label

        graph = _INPUT_VIDEO_REF.sub(through, str(out[graph_at + 1]))
        if not refs:
            die("internal: a BT.709 matrix conversion was requested for a -filter_complex that never reads "
                "input 0's video as [0:v] or [0:V:0]", kind="ffmpeg")
        # one conversion per input, split when the graph reads that input more than once
        # (speedramp.py trims [0:v] once per segment)
        chains = [f"{ref}{conv}" + (f",split={len(labels)}" if len(labels) > 1 else "") + "".join(labels)
                  for ref, *labels in refs.values()]
        out[graph_at + 1] = ";".join(chains + [graph])
        return out
    vf_at = next((k for k, a in enumerate(out[:-1]) if a == "-vf"), None)
    if vf_at is not None:
        out[vf_at + 1] = f"{conv},{out[vf_at + 1]}"
        return out
    return out[:at] + ["-vf", conv] + out[at:]


_HEX6 = re.compile(r"^[0-9A-Fa-f]{6}$")


def color_hex(value: str) -> str:
    """Normalise '#ffd200' / 'ffd200' / '0xFFD200' to 'FFD200'. Six hex digits only: the result is
    written into libass styles and drawtext/color options, so a six-letter colour name ("yellow")
    used to pass the length check and draw black, reported verified, and a quote or comma reached
    the filter graph."""
    v = str(value).strip().lstrip("#")
    if v.lower().startswith("0x"):
        v = v[2:]
    if not _HEX6.match(v):
        die(f"colour must be six hex digits RRGGBB (e.g. FFD200 or #ffd200), got '{value}'; colour names are not "
            "accepted here")
    return v.upper()


# Six or eight hex digits, with 0x, with # or bare (#535: bare ones starting with a digit, 0B1D2A,
# were refused, and seven passed with a prefix and failed inside ffmpeg), or a word that starts
# with a letter; alpha is 0..1 ("red@2" used to reach ffmpeg). Nothing else reaches the graph.
_HEX_DIGITS = r"(?:[0-9A-Fa-f]{8}|[0-9A-Fa-f]{6})"
_COLOR_TOKEN_RE = re.compile(r"^((?:0[xX]|#)?%s|[A-Za-z][A-Za-z0-9]*)(@(?:0(?:\.\d+)?|1(?:\.0+)?|\.\d+))?$" % _HEX_DIGITS)


def validate_color(value: str, flag: str = "--color") -> str:
    """Refuse a colour argument that isn't a plain ffmpeg colour token (named colour, RRGGBB[AA],
    0xRRGGBB[AA], #RRGGBB[AA], optionally with an @alpha suffix). Every caller that string-formats a colour flag
    straight into a filter graph (color=c=..., tpad=...:color=..., rotate=...:fillcolor=...) must
    validate it first -- ffmpeg filter options are comma/colon-delimited, so an unvalidated value
    containing those characters lets a caller splice in an entirely different filter (a real,
    demonstrated filter-graph injection: --color "black,drawtext=text=..." renders arbitrary burnt-in
    text), not just an odd colour. This is the same "no filter graph accepted from the caller"
    invariant every other typed flag in this codebase already holds to."""
    m = _COLOR_TOKEN_RE.match(value)
    if not m:
        die(f"{flag} must be a plain colour (a name, or six or eight hex digits RRGGBB[AA], bare or after 0x or #, "
            f"optionally @alpha), got '{value}'")
    word = m.group(1)
    if word[0].isalpha() and word.lower() not in FFMPEG_COLOR_NAMES and not _BARE_HEX.match(word):
        # A189 (#465): any word passed, and an unknown name failed inside ffmpeg ("Cannot find
        # color") as kind ffmpeg, after a dry run that had said completed. ffmpeg reads a word as
        # one of its names, or else as bare hex digits.
        die(f"{flag} {value!r}: {word!r} is not a colour name ffmpeg knows (`ffmpeg -colors` lists them) "
            "nor six or eight hex digits; use a name such as white, or 0xRRGGBB")
    return value


# The names av_parse_color() looks up, case-insensitively (`ffmpeg -colors`, the same list in 6.1
# through 8), plus the two it treats as a random colour. A word that is none of them is read as
# hex digits without a prefix, which works for six or eight of them.
FFMPEG_COLOR_NAMES = frozenset((
    "aliceblue antiquewhite aqua aquamarine azure beige bisque black blanchedalmond blue blueviolet brown "
    "burlywood cadetblue chartreuse chocolate coral cornflowerblue cornsilk crimson cyan darkblue darkcyan "
    "darkgoldenrod darkgray darkgreen darkkhaki darkmagenta darkolivegreen darkorange darkorchid darkred "
    "darksalmon darkseagreen darkslateblue darkslategray darkturquoise darkviolet deeppink deepskyblue dimgray "
    "dodgerblue firebrick floralwhite forestgreen fuchsia gainsboro ghostwhite gold goldenrod gray green "
    "greenyellow honeydew hotpink indianred indigo ivory khaki lavender lavenderblush lawngreen lemonchiffon "
    "lightblue lightcoral lightcyan lightgoldenrodyellow lightgreen lightgrey lightpink lightsalmon "
    "lightseagreen lightskyblue lightslategray lightsteelblue lightyellow lime limegreen linen magenta maroon "
    "mediumaquamarine mediumblue mediumorchid mediumpurple mediumseagreen mediumslateblue mediumspringgreen "
    "mediumturquoise mediumvioletred midnightblue mintcream mistyrose moccasin navajowhite navy oldlace olive "
    "olivedrab orange orangered orchid palegoldenrod palegreen paleturquoise palevioletred papayawhip peachpuff "
    "peru pink plum powderblue purple red rosybrown royalblue saddlebrown salmon sandybrown seagreen seashell "
    "sienna silver skyblue slateblue slategray snow springgreen steelblue tan teal thistle tomato turquoise "
    "violet wheat white whitesmoke yellow yellowgreen random bikeshed").split())
_BARE_HEX = re.compile(r"^(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$")


# The tonemap filter reads linear light in units of 100 nits (1.0 = SDR white; its default peak,
# 10, is 1000 nits), so the linearising zscale uses npl=100. Through 3.6.0 it used npl=--peak:
# a 1000-nit pixel came out as 1.0, which tonemap took as 100 nits, so nothing reached SDR white
# (PQ 1000 nits and HLG 100 % -> Y 151 of 235, HLG reference white 91) and raising --peak to a
# brighter master's darkened the picture further. zimg's HLG decode assumes a 1000-nit display,
# so an HLG picture always peaks at 1000 nits there, whatever --peak says.
TONEMAP_REFERENCE_NITS = 100.0
HLG_PEAK_NITS = 1000.0


def hdr_to_sdr_chain(meta: dict, tonemap: str, peak: float = 1000.0, desat: float = 0.0) -> str:
    """PQ / HLG / Dolby Vision to BT.709 SDR: linearise at 100 nits per unit, tone-map the source
    peak (`peak` nits for PQ, 1000 for HLG) to SDR white, re-encode as BT.709 limited range."""
    v = meta["video"]
    trc = v.get("color_transfer") or "smpte2084"
    prim = v.get("color_primaries") or "bt2020"
    space = v.get("color_space") or "bt2020nc"
    source_peak = HLG_PEAK_NITS if trc == "arib-std-b67" else peak
    # zscale needs explicit input tags when the file lacks them, and on 6.1 its `pin` does not
    # reach a frame whose own primaries are unspecified ("no path between colorspaces", kind
    # ffmpeg: --to-sdr --force on an untagged file failed through 3.8.8), so a frame missing a tag
    # is labelled with what the chain reads it as first
    missing = not (v.get("color_transfer") and v.get("color_primaries") and v.get("color_space"))
    label = [f"setparams=color_primaries={prim}:color_trc={trc}:colorspace={space}"] if missing else []
    chain: List[str] = label + [
        f"zscale=tin={trc}:pin={prim}:min={space}:rin={v.get('color_range') or 'tv'}:t=linear"
        f":npl={TONEMAP_REFERENCE_NITS:g}",
        "format=gbrpf32le",
        "zscale=p=bt709",
        f"tonemap=tonemap={tonemap}:desat={desat:g}:peak={source_peak / TONEMAP_REFERENCE_NITS:g}",
        "zscale=t=bt709:m=bt709:r=tv",
        "format=yuv420p",
    ]
    return ",".join(chain)


def bt2020_sdr_to_bt709_chain(meta: dict) -> str:
    """Gamut conversion only, for BT.2020 primaries on an SDR transfer (probe: `bt2020_or_hdr`
    true, `hdr_signal` false). Such a file is already display-referred SDR: linearising it with
    its own transfer, mapping the primaries to BT.709 and re-applying the BT.709 transfer keeps
    white at white and grey at grey. The tone map the HDR chain adds would treat 100 % SDR white
    as a fraction of a 1000-nit peak and darken the picture (white Y 235 -> 151, grey 126 -> 90)."""
    v = meta["video"]
    trc = v.get("color_transfer") or "bt709"
    space = v.get("color_space") or "bt2020nc"
    return ",".join([
        f"zscale=tin={trc}:pin=bt2020:min={space}:rin={v.get('color_range') or 'tv'}:t=linear",
        "format=gbrpf32le",
        "zscale=p=bt709",
        "zscale=t=bt709:m=bt709:r=tv",
        "format=yuv420p",
    ])


def is_bt2020_sdr(v: dict) -> bool:
    """BT.2020 primaries on a non-HDR transfer and no Dolby Vision: gamut-only --to-sdr."""
    return bool(v.get("bt2020_or_hdr")) and not v.get("hdr_signal") and not v.get("dolby_vision") \
        and v.get("color_transfer") not in ("smpte2084", "arib-std-b67")
